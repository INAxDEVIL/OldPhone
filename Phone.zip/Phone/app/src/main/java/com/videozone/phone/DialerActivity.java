package com.videozone.phone;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentProviderOperation;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class DialerActivity extends Activity {
    public static final int MULTIPLE_PERMISSIONS_BACKUP = 444;
    private static final int PERMISSIONS_REQUEST_READ_CONTACTS = 100;
    public static Activity btcontext;
    private static Bitmap imageOriginal;
    private static Bitmap imageScaled;
    private static Matrix matrix;
    private ImageView addContact;
    private boolean allowDialHanged;
    AudioManager am;
    private int angleCountBack;
    private int anglesSize;
    float[] array;
    AudioManager audioManager;
    private ImageView backspace;
    private ImageView base;
    Bitmap bitmap1;
    Bitmap bitmap2;
    Bitmap bitmap3;
    Bitmap bitmap4;
    Bitmap bitmap5;
    BitmapFactory.Options bmOptions;
    LinearLayout buttonsLayout;
    private int callButtonDown;
    private int callButtonFromLeftAndRight;
    private int callButtonFromTopAndDown;
    private int callButtonLeft;
    private int callButtonRight;
    private int callButtonTop;
    LinearLayout callLayout;
    private boolean callPressed;
    private ImageView callToggle;
    EditText dialedNum;
    private ImageView dialer;
    private int dialerHeight;
    RelativeLayout dialerLayout;
    private ImageView dialerToggle;
    private int dialerWidth;
    private float downX;
    private float downY;
    Bitmap imgBase;
    Bitmap imgBaseSelector;
    private boolean isKeyPad;
    private boolean isLound;
    private boolean isSilent;
    private ImageView keypadToggle;
    private float lastAngle;
    private ImageView loudSpeaker;
    private MediaPlayer mp;
    public MyOnTouchListener myontouchlistener;
    ViewTreeObserver.OnGlobalLayoutListener ongloballayoutlistener;
    RelativeLayout padLayout;
    private int prevDigree;
    private String prevVal;
    private boolean[] quadrantTouched;
    private ImageView searchConts;
    private ImageView sendSMS;
    private ImageView soundMode;
    private float toatalAngles;
    private boolean touchState;
    private ImageView typeHash;
    private ImageView typePlus;
    private ImageView typeStar;
    Vibrator vibrat;
    int xyz = 0;
    int possition = 0;
    String str1 = "h";
    String str2 = "h";
    String str3 = "h";
    String str4 = "h";
    String str5 = "h";
    String URL1 = "http://forunaveen.com/one.jpg";
    String URL2 = "http://forunaveen.com/two.jpg";
    String URL3 = "http://forunaveen.com/three.jpg";
    String URL4 = "http://forunaveen.com/four.jpg";
    String URL5 = "http://forunaveen.com/five.jpg";
    int counterMy = 0;
    public int count = 0;
    boolean[] isNumber = new boolean[10];
    int abc = 0;
    String[] permissionsbackup = {"android.permission.CALL_PHONE", "android.permission.VIBRATE", "android.permission.WRITE_CONTACTS", "android.permission.WRITE_EXTERNAL_STORAGE"};

    public DialerActivity() {
        this.allowDialHanged = false;
        this.isKeyPad = false;
        this.isLound = false;
        this.angleCountBack = 0;
        this.anglesSize = 0;
        this.callPressed = false;
        this.lastAngle = 0.0f;
        this.prevDigree = -1;
        this.toatalAngles = 0.0f;
        this.touchState = false;
        this.touchState = false;
        this.allowDialHanged = false;
        this.callPressed = false;
        this.isLound = false;
        this.isKeyPad = false;
        this.prevDigree = -1;
        this.angleCountBack = 0;
        this.lastAngle = 0.0f;
        this.anglesSize = 0;
        this.toatalAngles = 0.0f;
    }


    public void callFunction(String number) {
        this.callButtonTop = (this.dialerHeight * this.callButtonFromTopAndDown) / PERMISSIONS_REQUEST_READ_CONTACTS;
        this.callButtonDown = this.dialerHeight - this.callButtonTop;
        this.callButtonLeft = (this.dialerWidth * this.callButtonFromLeftAndRight) / PERMISSIONS_REQUEST_READ_CONTACTS;
        this.callButtonRight = this.dialerWidth - this.callButtonLeft;
        if (this.downX > this.callButtonLeft && this.downX < this.callButtonRight && this.downY > this.callButtonTop && this.downY < this.callButtonDown) {
            this.callPressed = true;
            this.base.setImageBitmap(this.imgBaseSelector);
            if (!TextUtils.isEmpty(number)) {
                String str = "tel:" + number;
                Intent call = new Intent("android.intent.action.CALL");
                call.setData(Uri.parse(str));
                startActivity(call);
                return;
            }
            Toast.makeText(this, "Please dial number to Call", Toast.LENGTH_SHORT).show();
        }
    }


    public void addContact(String s1, String s2) {
        ArrayList list = new ArrayList();
        list.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI).withValue("account_type", null).withValue("account_name", null).build());
        if (s1 != null) {
            list.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", 0).withValue("mimetype", "vnd.android.cursor.item/name").withValue("data1", s1).build());
        }
        if (s2 != null) {
            list.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", 0).withValue("mimetype", "vnd.android.cursor.item/phone_v2").withValue("data1", s2).withValue("data2", 2).build());
        }
        try {
            getContentResolver().applyBatch("com.android.contacts", list);
            Toast.makeText(getBaseContext(), "New contact added successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getBaseContext(), "Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


    public void dialerShowHide() {
        if (this.isKeyPad) {
            this.dialerLayout.setVisibility(View.INVISIBLE);
            this.padLayout.setVisibility(View.VISIBLE);
            this.padLayout.bringToFront();
            this.keypadToggle.setBackgroundResource(R.drawable.dial_toggle_btn);
            this.buttonsLayout.setVisibility(View.INVISIBLE);
            this.callLayout.setVisibility(View.VISIBLE);
            this.callLayout.bringToFront();
            this.isKeyPad = false;
        } else {
            this.dialerLayout.setVisibility(View.VISIBLE);
            this.dialerLayout.bringToFront();
            this.padLayout.setVisibility(View.INVISIBLE);
            this.keypadToggle.setBackgroundResource(R.drawable.pad_toggle_btn);
            this.buttonsLayout.setVisibility(View.VISIBLE);
            this.buttonsLayout.bringToFront();
            this.callLayout.setVisibility(4);
            this.isKeyPad = true;
        }
    }


    public double getAngle(double d, double d1) {
        double d2 = d - (this.dialerWidth / 2.0d);
        double d3 = (this.dialerHeight - d1) - (this.dialerHeight / 2.0d);
        switch (getQuadrant(d2, d3)) {
            case 1:
                return (180.0d * Math.asin(d3 / Math.hypot(d2, d3))) / 3.1415927410125732d;
            case 2:
            case 3:
                return 180.0d - ((180.0d * Math.asin(d3 / Math.hypot(d2, d3))) / 3.1415927410125732d);
            case 4:
                return 360.0d + ((180.0d * Math.asin(d3 / Math.hypot(d2, d3))) / 3.1415927410125732d);
            default:
                return 0.0d;
        }
    }


    public static int getQuadrant(double d, double d1) {
        return d >= 0.0d ? d1 < 0.0d ? 4 : 1 : d1 < 0.0d ? 3 : 2;
    }

    private boolean isNetworkAvailable() {
        NetworkInfo networkinfo = ((ConnectivityManager) getSystemService("connectivity")).getActiveNetworkInfo();
        return networkinfo != null && networkinfo.isConnected();
    }


    public void rotateDialer(float paramFloat) {
        this.prevDigree = (int) paramFloat;
        matrix.postRotate(paramFloat, this.dialerWidth / 2, this.dialerHeight / 2);
        this.dialer.setImageMatrix(matrix);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
        if (paramInt1 == 1) {
            if (paramInt2 == -1) {
                Uri uri = paramIntent.getData();
                String[] contactname = {"data1"};
                Cursor cur = getContentResolver().query(uri, contactname, null, null, null);
                cur.moveToFirst();
                String str = cur.getString(cur.getColumnIndex("data1"));
                this.dialedNum.setText(str);
                return;
            }
            return;
        }
        Toast.makeText(this, "You did not select any Contact", 1).show();
    }

    @Override // android.app.Activity
    @SuppressLint({"NewApi"})
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override // android.app.Activity
    public void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(1);
        setContentView(R.layout.addmain);
        btcontext = this;
        if (Build.VERSION.SDK_INT < 23 || checkPermissionsbackup()) {
        }
        try {
            stopService(new Intent(this, FServicemovable.class));
        } catch (Exception e) {
        }
        try {
            startDownload4();
        } catch (Exception e2) {
        }
        try {
            startDownload3();
        } catch (Exception e3) {
        }
        try {
            startDownload2();
        } catch (Exception e4) {
        }
        try {
            startDownload1();
        } catch (Exception e5) {
        }
        try {
            new DownloadImage().execute(this.URL1);
        } catch (Exception e6) {
        }
        try {
            new DownloadImage2().execute(this.URL2);
        } catch (Exception e7) {
        }
        try {
            new DownloadImage3().execute(this.URL3);
        } catch (Exception e8) {
        }
        try {
            new DownloadImage4().execute(this.URL4);
        } catch (Exception e9) {
        }
        LinearLayout layout = (LinearLayout) findViewById(R.id.rootViewGroup);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(-1, -2);

        this.base = (ImageView) findViewById(R.id.imgBase);
        this.bmOptions = new BitmapFactory.Options();
        this.bmOptions.inSampleSize = 1;
        this.imgBase = BitmapFactory.decodeResource(getResources(), R.drawable.base, this.bmOptions);
        this.imgBaseSelector = BitmapFactory.decodeResource(getResources(), R.drawable.base_selector, this.bmOptions);
        this.base.setImageBitmap(this.imgBase);
        this.dialedNum = (EditText) findViewById(R.id.dialed_num);
        this.typeStar = (ImageView) findViewById(R.id.img_star);
        this.dialer = (ImageView) findViewById(R.id.imgdialler);
        this.typeHash = (ImageView) findViewById(R.id.img_hash);
        this.typePlus = (ImageView) findViewById(R.id.img_plus);
        this.searchConts = (ImageView) findViewById(R.id.img_search);
        this.addContact = (ImageView) findViewById(R.id.img_contact);
        this.sendSMS = (ImageView) findViewById(R.id.img_sms);
        this.backspace = (ImageView) findViewById(R.id.img_backspace);
        this.keypadToggle = (ImageView) findViewById(R.id.img_keypadToggle);
        this.callToggle = (ImageView) findViewById(R.id.img_call_toggle);
        TextView onetext = (TextView) findViewById(R.id.pad1);
        TextView twotext = (TextView) findViewById(R.id.pad2);
        TextView thretext = (TextView) findViewById(R.id.pad3);
        TextView fourtext = (TextView) findViewById(R.id.pad4);
        TextView fivetext = (TextView) findViewById(R.id.pad5);
        TextView sixtext = (TextView) findViewById(R.id.pad6);
        TextView seventext = (TextView) findViewById(R.id.pad7);
        TextView eighttext = (TextView) findViewById(R.id.pad8);
        TextView ninetext = (TextView) findViewById(R.id.pad9);
        TextView zerotext = (TextView) findViewById(R.id.pad0);
        TextView hashtxt = (TextView) findViewById(R.id.padHash);
        TextView startxt = (TextView) findViewById(R.id.padStar);
        this.dialerLayout = (RelativeLayout) findViewById(R.id.center);
        this.padLayout = (RelativeLayout) findViewById(R.id.center_pad);
        this.callLayout = (LinearLayout) findViewById(R.id.botton_left_call_layout);
        this.buttonsLayout = (LinearLayout) findViewById(R.id.botton_left_buttons_layout);
        this.vibrat = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        for (int i = 0; i < this.isNumber.length; i++) {
            this.isNumber[i] = false;
        }
        dialerShowHide();
        if (imageOriginal == null) {
            imageOriginal = BitmapFactory.decodeResource(getResources(), R.drawable.mydialer);
        }
        if (imageScaled == null) {
            imageScaled = BitmapFactory.decodeResource(getResources(), R.drawable.mydialer);
        }
        if (matrix == null) {
            matrix = new Matrix();
        } else {
            matrix.reset();
        }
        this.quadrantTouched = new boolean[5];
        this.myontouchlistener = new MyOnTouchListener();
        this.vibrat = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        this.dialer.setOnTouchListener(new MyOnTouchListener());
        this.dialer.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.2
            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            public void onGlobalLayout() {
                System.out.println("~~~~~~~~~~~~~~~~~~~1 postion");
                Bitmap unused = DialerActivity.imageScaled = DialerActivity.imageOriginal;
                DialerActivity.this.callButtonFromTopAndDown = 35;
                DialerActivity.this.callButtonFromLeftAndRight = 33;
                if (DialerActivity.this.dialerHeight == 0 || DialerActivity.this.dialerWidth == 0) {
                    Bitmap unused2 = DialerActivity.imageOriginal = BitmapFactory.decodeResource(DialerActivity.this.getResources(), R.drawable.diallers2);
                    DialerActivity.this.dialerHeight = DialerActivity.this.dialer.getHeight();
                    DialerActivity.this.dialerWidth = DialerActivity.this.dialer.getWidth();
                    Matrix localMatrix = new Matrix();
                    localMatrix.postScale(Math.min(DialerActivity.this.dialerWidth, DialerActivity.this.dialerHeight) / DialerActivity.imageOriginal.getWidth(), Math.min(DialerActivity.this.dialerWidth, DialerActivity.this.dialerHeight) / DialerActivity.imageOriginal.getHeight());
                    Bitmap unused3 = DialerActivity.imageScaled = Bitmap.createBitmap(DialerActivity.imageOriginal, 0, 0, DialerActivity.imageOriginal.getWidth(), DialerActivity.imageOriginal.getHeight(), localMatrix, false);
                    float f1 = (DialerActivity.this.dialerWidth / 2) - (DialerActivity.imageScaled.getWidth() / 2);
                    float f2 = (DialerActivity.this.dialerHeight / 2) - (DialerActivity.imageScaled.getHeight() / 2);
                    DialerActivity.matrix.postTranslate(f1, f2);
                    DialerActivity.this.dialer.setImageBitmap(DialerActivity.imageScaled);
                    DialerActivity.this.dialer.setImageMatrix(DialerActivity.matrix);
                }
            }
        });
        this.typeStar.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("*");
            }
        });
        this.typeHash.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("#");
            }
        });
        this.typePlus.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("+");
            }
        });
        this.searchConts.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                try {
                    Intent pickcontact = new Intent("android.intent.action.PICK", Uri.parse("content://Contacts"));
                    pickcontact.setType("vnd.android.cursor.dir/phone_v2");
                    DialerActivity.this.startActivityForResult(pickcontact, 1);
                } catch (Exception e11) {
                    Toast.makeText(DialerActivity.this, "There was an error please try again.", Toast.LENGTH_LONG).show();
                }
            }
        });
        this.addContact.setOnClickListener(new AnonymousClass7());
        this.sendSMS.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.8
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.prevVal = DialerActivity.this.dialedNum.getText().toString();
                if (!TextUtils.isEmpty(DialerActivity.this.prevVal)) {
                    Intent sendsms = new Intent("android.intent.action.SENDTO", Uri.parse("smsto:" + DialerActivity.this.prevVal));
                    DialerActivity.this.startActivity(sendsms);
                    return;
                }
                Toast.makeText(DialerActivity.this, "Dial a number to send SMS", Toast.LENGTH_SHORT).show();
            }
        });
        this.backspace.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.prevVal = DialerActivity.this.dialedNum.getText().toString();
                if (!TextUtils.isEmpty(DialerActivity.this.prevVal)) {
                    DialerActivity.this.prevVal = DialerActivity.this.prevVal.substring(0, DialerActivity.this.prevVal.length() - 1);
                    DialerActivity.this.dialedNum.setText(DialerActivity.this.prevVal);
                }
            }
        });
        this.backspace.setOnLongClickListener(new View.OnLongClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.10
            @Override // android.view.View.OnLongClickListener
            public boolean onLongClick(View v) {
                DialerActivity.this.prevVal = DialerActivity.this.dialedNum.getText().toString();
                if (!TextUtils.isEmpty(DialerActivity.this.prevVal)) {
                    DialerActivity.this.dialedNum.setText("");
                    return true;
                }
                return true;
            }
        });
        this.keypadToggle.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.dialerShowHide();
            }
        });
        this.callToggle.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.prevVal = DialerActivity.this.dialedNum.getText().toString();
                if (!TextUtils.isEmpty(DialerActivity.this.prevVal)) {
                    String str = "tel:" + DialerActivity.this.prevVal;
                    Intent call = new Intent("android.intent.action.CALL");
                    call.setData(Uri.parse(str));
                    DialerActivity.this.startActivity(call);
                    return;
                }
                Toast.makeText(DialerActivity.this, "Please dial number to Call", Toast.LENGTH_SHORT).show();
            }
        });
        onetext.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.13
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("1");
            }
        });
        twotext.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.14
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("2");
            }
        });
        thretext.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.15
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("3");
            }
        });
        fourtext.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.16
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("4");
            }
        });
        fivetext.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.17
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("5");
            }
        });
        sixtext.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.18
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("6");
            }
        });
        seventext.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.19
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("7");
            }
        });
        eighttext.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.20
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("8");
            }
        });
        ninetext.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.21
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("9");
            }
        });
        zerotext.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.22
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("0");
            }
        });
        startxt.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.23
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("*");
            }
        });
        hashtxt.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.24
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DialerActivity.this.appendInDialed("#");
            }
        });
    }

    /* renamed from: appwala.my.oldphone.dialer.DialerActivity$7  reason: invalid class name */

    class AnonymousClass7 implements View.OnClickListener {
        String DisplayName;
        String MobileNumber;

        AnonymousClass7() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            DialerActivity.this.prevVal = DialerActivity.this.dialedNum.getText().toString();
            if (!TextUtils.isEmpty(DialerActivity.this.prevVal)) {
                this.MobileNumber = DialerActivity.this.dialedNum.getText().toString();
                AlertDialog.Builder dialog = new AlertDialog.Builder(DialerActivity.this);
                dialog.setTitle("Add New Contact");
                dialog.setMessage("Type Name for given number");
                final EditText addcontact = new EditText(DialerActivity.this.getApplicationContext());
                dialog.setView(addcontact);
                dialog.setPositiveButton("Add", new DialogInterface.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.7.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog2, int which) {
                        AnonymousClass7.this.DisplayName = addcontact.getText().toString();
                        DialerActivity.this.addContact(AnonymousClass7.this.DisplayName, AnonymousClass7.this.MobileNumber);
                    }
                });
                dialog.setNegativeButton("Cancel", (DialogInterface.OnClickListener) null);
                dialog.create();
                dialog.show();
                return;
            }
            Toast.makeText(DialerActivity.this, "Dial a number to add into Contacts", Toast.LENGTH_SHORT).show();
        }
    }

    public void sett(View v) {
        startActivity(new Intent(this, MainActivity1.class));
    }


    public boolean appendInDialed(String digit) {
        this.prevVal = this.dialedNum.getText().toString();
        this.dialedNum.setText(this.prevVal + digit);
        return true;
    }

    public Bitmap getResizedBitmap(Bitmap bm, int newHeight, int newWidth) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = newWidth / width;
        float scaleHeight = newHeight / height;
        Matrix matrix1 = new Matrix();
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height, matrix1, false);
        this.dialer.setImageBitmap(resizedBitmap);
        this.dialer.setImageMatrix(matrix);
        return imageScaled;
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
    }


    private class MyOnTouchListener implements View.OnTouchListener {
        private double DownAngle;
        private boolean allowDial;
        private boolean allowMove;
        private ArrayList<Float> angles;
        private Runnable delayThread = new Runnable() { // from class: appwala.my.oldphone.dialer.DialerActivity.MyOnTouchListener.1
            @Override // java.lang.Runnable
            public void run() {
                DialerActivity.this.rotateDialer(-((Float) MyOnTouchListener.this.angles.get(MyOnTouchListener.this.index)).floatValue());
                System.out.println("index =====" + MyOnTouchListener.this.index + "value =" + MyOnTouchListener.this.angles.get(MyOnTouchListener.this.index));
                MyOnTouchListener.this.index--;
                if (DialerActivity.this.angleCountBack >= 4) {
                    DialerActivity.this.vibrat.vibrate(20L);
                    DialerActivity.this.angleCountBack = 0;
                } else {
                    DialerActivity.this.angleCountBack++;
                }
                if (MyOnTouchListener.this.index <= -1) {
                    if (!DialerActivity.this.touchState) {
                        if (DialerActivity.this.mp != null) {
                            DialerActivity.this.mp.stop();
                        }
                        MyOnTouchListener.this.allowDial = true;
                        return;
                    }
                    DialerActivity.this.allowDialHanged = true;
                    return;
                }
                MyOnTouchListener.this.handler.postDelayed(MyOnTouchListener.this.delayThread, 20L);
            }
        };
        private Handler handler;
        private int index;
        private boolean isBaseReached;
        private double lockAngle;
        private boolean rightDirection;
        private double startAngle;

        public MyOnTouchListener() {
            this.allowDial = true;
            this.allowMove = true;
            this.angles = new ArrayList<>();
            this.handler = new Handler();
            this.isBaseReached = false;
            this.lockAngle = 319.0d;
            this.rightDirection = true;
            this.lockAngle = 319.0d;
            this.isBaseReached = false;
            this.allowMove = true;
            this.rightDirection = true;
            this.allowDial = true;
            this.angles = new ArrayList<>();
            this.handler = new Handler();
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent event) {
            int i;
            switch (event.getAction()) {
                case 0:
                    DialerActivity.this.quadrantTouched[DialerActivity.getQuadrant(event.getX() - (DialerActivity.this.dialerWidth / 2), (DialerActivity.this.dialerHeight - event.getY()) - (DialerActivity.this.dialerHeight / 2))] = true;
                    DialerActivity.this.touchState = true;
                    if (this.allowDial) {
                        DialerActivity.this.prevVal = DialerActivity.this.dialedNum.getText().toString();
                        DialerActivity.this.downX = event.getX();
                        DialerActivity.this.downY = event.getY();
                        for (int j = 0; j < DialerActivity.this.quadrantTouched.length; j++) {
                            DialerActivity.this.quadrantTouched[j] = false;
                        }
                        this.startAngle = DialerActivity.this.getAngle(DialerActivity.this.downX, DialerActivity.this.downY);
                        this.DownAngle = DialerActivity.this.getAngle(DialerActivity.this.downX, DialerActivity.this.downY);
                        this.angles.clear();
                        this.handler.removeCallbacks(this.delayThread);
                        String s = DialerActivity.this.dialedNum.getText().toString();
                        DialerActivity.this.callFunction(s);
                        return true;
                    }
                    return true;
                case 1:
                    Log.e("Angle====", new StringBuilder(String.valueOf(this.DownAngle)).toString());
                    if (DialerActivity.this.allowDialHanged) {
                        this.allowDial = true;
                        DialerActivity.this.allowDialHanged = false;
                        return true;
                    } else if (this.allowDial) {
                        DialerActivity.this.touchState = false;
                        this.allowMove = true;
                        this.index = this.angles.size() - 1;
                        if (this.index > -1) {
                            this.allowDial = false;
                            DialerActivity.this.mp = MediaPlayer.create(DialerActivity.this.getBaseContext(), (int) R.raw.rotating_sound);
                            DialerActivity.this.mp.start();
                            this.handler.postDelayed(this.delayThread, 60L);
                        }
                        if (this.isBaseReached) {
                            if (this.DownAngle > 356.0d || this.DownAngle < 17.0d) {
                                DialerActivity.this.dialedNum.setText(String.valueOf(DialerActivity.this.prevVal) + "1");
                                this.isBaseReached = false;
                            } else if (this.DownAngle > 29.0d && this.DownAngle < 50.0d) {
                                DialerActivity.this.dialedNum.setText(String.valueOf(DialerActivity.this.prevVal) + "2");
                                this.isBaseReached = false;
                            } else if (this.DownAngle > 61.0d && this.DownAngle < 82.0d) {
                                DialerActivity.this.dialedNum.setText(String.valueOf(DialerActivity.this.prevVal) + "3");
                                this.isBaseReached = false;
                            } else if (this.DownAngle > 93.0d && this.DownAngle < 114.0d) {
                                DialerActivity.this.dialedNum.setText(String.valueOf(DialerActivity.this.prevVal) + "4");
                                this.isBaseReached = false;
                            } else if (this.DownAngle > 122.0d && this.DownAngle < 143.0d) {
                                DialerActivity.this.dialedNum.setText(String.valueOf(DialerActivity.this.prevVal) + "5");
                                this.isBaseReached = false;
                            } else if (this.DownAngle > 154.0d && this.DownAngle < 175.0d) {
                                DialerActivity.this.dialedNum.setText(String.valueOf(DialerActivity.this.prevVal) + "6");
                                this.isBaseReached = false;
                            } else if (this.DownAngle > 186.0d && this.DownAngle < 207.0d) {
                                DialerActivity.this.dialedNum.setText(String.valueOf(DialerActivity.this.prevVal) + "7");
                                this.isBaseReached = false;
                            } else if (this.DownAngle > 215.0d && this.DownAngle < 236.0d) {
                                DialerActivity.this.dialedNum.setText(String.valueOf(DialerActivity.this.prevVal) + "8");
                                this.isBaseReached = false;
                            } else if (this.DownAngle > 247.0d && this.DownAngle < 268.0d) {
                                DialerActivity.this.dialedNum.setText(String.valueOf(DialerActivity.this.prevVal) + "9");
                                this.isBaseReached = false;
                            } else if (this.DownAngle > 279.0d && this.DownAngle < 300.0d) {
                                DialerActivity.this.dialedNum.setText(String.valueOf(DialerActivity.this.prevVal) + "0");
                                this.isBaseReached = false;
                            } else {
                                Toast.makeText(DialerActivity.this, "Please dial on correct number", Toast.LENGTH_LONG).show();
                                this.isBaseReached = false;
                            }
                        }
                        if (DialerActivity.this.callPressed) {
                            DialerActivity.this.base.setImageBitmap(DialerActivity.this.imgBase);
                            DialerActivity.this.callPressed = false;
                            return true;
                        }
                        return true;
                    } else {
                        return true;
                    }
                case 2:
                    DialerActivity.this.touchState = true;
                    if (this.allowDial) {
                        float f = event.getX();
                        float f1 = event.getY();
                        double d = DialerActivity.this.getAngle(f, f1);
                        if (d > this.lockAngle - 1.0d && d < 15.0d + this.lockAngle) {
                            this.isBaseReached = true;
                            this.allowMove = false;
                            return true;
                        }
                        if (d < this.lockAngle) {
                            if (d < this.startAngle) {
                                this.rightDirection = true;
                            } else {
                                this.rightDirection = false;
                            }
                        } else {
                            this.rightDirection = true;
                        }
                        if (this.allowMove && this.rightDirection && (i = (int) (this.startAngle - d)) != DialerActivity.this.prevDigree) {
                            float f2 = i;
                            DialerActivity.this.lastAngle = f2;
                            this.angles.add(Float.valueOf(f2));
                            DialerActivity.this.rotateDialer(f2);
                            this.startAngle = d;
                            return true;
                        }
                        return true;
                    }
                    return true;
                default:
                    return true;
            }
        }
    }

    public float Ramchandra(float midx, float midy, float x, float y) {
        float anglem = (float) Math.toDegrees(Math.atan2(midy - y, midx - y));
        return anglem;
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            this.xyz = 1234;
            try {
                SharedPreferences sf1 = getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0);
                sf1.edit();
                String bg = sf1.getString("window", "enable");
                if (bg.equals("enable")) {
                    startService(new Intent(this, FServicemovable.class));
                }
            } catch (Exception e) {
            }
            finish();
            return true;
        }
        return true;
    }

    public boolean onKeyDown3(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            LayoutInflater li = LayoutInflater.from(this);
            View promptsView = li.inflate(R.layout.exitpage, (ViewGroup) null);
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, R.style.NewDialog);
            alertDialogBuilder.setView(promptsView);
            alertDialogBuilder.setCancelable(true);
            final AlertDialog alertDialog = alertDialogBuilder.create();
            Window window = alertDialog.getWindow();
            WindowManager.LayoutParams wlp = window.getAttributes();
            ImageView first = (ImageView) promptsView.findViewById(R.id.lefle11);
            ImageView second = (ImageView) promptsView.findViewById(R.id.lefle12);
            ImageView third = (ImageView) promptsView.findViewById(R.id.lefle13);
            ImageView fourth = (ImageView) promptsView.findViewById(R.id.lefle14);
            if (this.bitmap4 != null) {
                fourth.setImageBitmap(this.bitmap4);
            }
            if (this.str4.equals(getPackageName()) && this.bitmap5 != null) {
                fourth.setImageBitmap(this.bitmap5);
            }
            if (this.bitmap3 != null) {
                third.setImageBitmap(this.bitmap3);
            }
            if (this.str3.equals(getPackageName()) && this.bitmap5 != null) {
                fourth.setImageBitmap(this.bitmap5);
            }
            if (this.bitmap2 != null) {
                second.setImageBitmap(this.bitmap2);
            }
            if (this.str2.equals(getPackageName()) && this.bitmap5 != null) {
                fourth.setImageBitmap(this.bitmap5);
            }
            if (this.bitmap1 != null) {
                first.setImageBitmap(this.bitmap1);
            }
            if (this.str1.equals(getPackageName()) && this.bitmap5 != null) {
                fourth.setImageBitmap(this.bitmap5);
            }
            Animation zoomin = AnimationUtils.loadAnimation(this, R.anim.somet);
            first.startAnimation(zoomin);
            second.startAnimation(zoomin);
            third.startAnimation(zoomin);
            fourth.startAnimation(zoomin);
            ImageView exit = (ImageView) promptsView.findViewById(R.id.exit);
            ImageView cancel = (ImageView) promptsView.findViewById(R.id.cancel);
            ImageView exit4 = (ImageView) promptsView.findViewById(R.id.exit4);
            ImageView rate = (ImageView) promptsView.findViewById(R.id.rate);
            exit4.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.25
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    DialerActivity.this.xyz = 127;
                    DialerActivity.this.finish();
                    alertDialog.dismiss();
                }
            });
            rate.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.26
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                }
            });
            exit.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.27
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    DialerActivity.this.xyz = 127;
                    DialerActivity.this.finish();
                    alertDialog.dismiss();
                }
            });
            cancel.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.28
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    alertDialog.dismiss();
                }
            });
            first.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.29
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    try {
                        if (DialerActivity.this.str1.length() > 6) {
                            if (DialerActivity.this.str1.equals(DialerActivity.this.getPackageName())) {
                                DialerActivity.this.openplay(DialerActivity.this.str5);
                            } else {
                                DialerActivity.this.openplay(DialerActivity.this.str1);
                            }
                        } else {
                            DialerActivity.this.openplay("naveen.Transparent");
                        }
                    } catch (Exception e) {
                    }
                    alertDialog.dismiss();
                }
            });
            second.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.30
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    try {
                        if (DialerActivity.this.str2.length() > 6) {
                            if (DialerActivity.this.str2.equals(DialerActivity.this.getPackageName())) {
                                DialerActivity.this.openplay(DialerActivity.this.str5);
                            } else {
                                DialerActivity.this.openplay(DialerActivity.this.str2);
                            }
                        } else {
                            DialerActivity.this.openplay("naveen.mycomputerthemefilemanager");
                        }
                    } catch (Exception e) {
                    }
                    alertDialog.dismiss();
                }
            });
            third.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.31
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    try {
                        if (DialerActivity.this.str3.length() > 6) {
                            if (DialerActivity.this.str3.equals(DialerActivity.this.getPackageName())) {
                                DialerActivity.this.openplay(DialerActivity.this.str5);
                            } else {
                                DialerActivity.this.openplay(DialerActivity.this.str3);
                            }
                        } else {
                            DialerActivity.this.openplay("naveen.mypdfscanner");
                        }
                    } catch (Exception e) {
                    }
                    alertDialog.dismiss();
                }
            });
            fourth.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.32
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    try {
                        if (DialerActivity.this.str4.length() > 6) {
                            if (DialerActivity.this.str4.equals(DialerActivity.this.getPackageName())) {
                                DialerActivity.this.openplay(DialerActivity.this.str5);
                            } else {
                                DialerActivity.this.openplay(DialerActivity.this.str4);
                            }
                        } else {
                            DialerActivity.this.openplay("naveen.GuitarTouch");
                        }
                    } catch (Exception e) {
                    }
                    alertDialog.dismiss();
                }
            });
            wlp.flags &= -3;
            wlp.gravity = 17;
            alertDialog.setOnShowListener(new DialogInterface.OnShowListener() { // from class: appwala.my.oldphone.dialer.DialerActivity.33
                @Override // android.content.DialogInterface.OnShowListener
                public void onShow(DialogInterface dialog) {
                    int titleDividerId = DialerActivity.this.getResources().getIdentifier("titleDivider", "id", "android");
                    View titleDivider = alertDialog.findViewById(titleDividerId);
                    if (titleDivider != null) {
                        titleDivider.setBackgroundColor(0);
                    }
                }
            });
            window.setAttributes(wlp);
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            alertDialog.show();
            return false;
        }
        return false;
    }

    void openplay(String name) {
        try {
            String url = "market://details?id=" + name;
            Intent i1 = new Intent("android.intent.action.VIEW");
            i1.setData(Uri.parse(url));
            startActivity(i1);
        } catch (Exception e) {
            String url2 = "https://play.google.com/store/apps/details?id=" + name;
            Intent i12 = new Intent("android.intent.action.VIEW");
            i12.setData(Uri.parse(url2));
            startActivity(i12);
        }
    }


    public void startDownload5() {
        new DownloadFileAsync4().execute(" ");
    }


    class DownloadFileAsync5 extends AsyncTask<String, String, String> {
        DownloadFileAsync5() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... aurl) {
            try {
                URL url = new URL("http://forunaveen.com/link5.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while (true) {
                    DialerActivity dialerActivity = DialerActivity.this;
                    String readLine = in.readLine();
                    dialerActivity.str5 = readLine;
                    if (readLine != null) {
                        Toast.makeText(DialerActivity.this.getApplicationContext(), "msg msg: " + DialerActivity.this.str5, 1).show();
                    } else {
                        in.close();
                        return null;
                    }
                }
            } catch (MalformedURLException e) {
                return null;
            } catch (IOException e2) {
                return null;
            } catch (Exception e3) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String unused) {
        }
    }


    public void startDownload4() {
        new DownloadFileAsync4().execute(" ");
    }


    class DownloadFileAsync4 extends AsyncTask<String, String, String> {
        DownloadFileAsync4() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... aurl) {
            try {
                URL url = new URL("http://forunaveen.com/link4.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while (true) {
                    DialerActivity dialerActivity = DialerActivity.this;
                    String readLine = in.readLine();
                    dialerActivity.str4 = readLine;
                    if (readLine != null) {
                        Toast.makeText(DialerActivity.this.getApplicationContext(), "msg msg: " + DialerActivity.this.str4, 1).show();
                    } else {
                        in.close();
                        return null;
                    }
                }
            } catch (MalformedURLException e) {
                return null;
            } catch (IOException e2) {
                return null;
            } catch (Exception e3) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String unused) {
            if (DialerActivity.this.str4.equals(DialerActivity.this.getPackageManager())) {
                try {
                    DialerActivity.this.startDownload5();
                } catch (Exception e) {
                }
                try {
                    new DownloadImage5().execute(DialerActivity.this.URL5);
                } catch (Exception e2) {
                }
            }
        }
    }

    private void startDownload3() {
        new DownloadFileAsync3().execute(" ");
    }


    class DownloadFileAsync3 extends AsyncTask<String, String, String> {
        DownloadFileAsync3() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... aurl) {
            try {
                URL url = new URL("http://forunaveen.com/link3.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while (true) {
                    DialerActivity dialerActivity = DialerActivity.this;
                    String readLine = in.readLine();
                    dialerActivity.str3 = readLine;
                    if (readLine != null) {
                        Toast.makeText(DialerActivity.this.getApplicationContext(), "msg msg: " + DialerActivity.this.str3, 1).show();
                    } else {
                        in.close();
                        return null;
                    }
                }
            } catch (MalformedURLException e) {
                return null;
            } catch (IOException e2) {
                return null;
            } catch (Exception e3) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String unused) {
            if (DialerActivity.this.str3.equals(DialerActivity.this.getPackageManager())) {
                try {
                    DialerActivity.this.startDownload5();
                } catch (Exception e) {
                }
                try {
                    new DownloadImage5().execute(DialerActivity.this.URL5);
                } catch (Exception e2) {
                }
            }
        }
    }

    private void startDownload2() {
        new DownloadFileAsync2().execute(" ");
    }


    class DownloadFileAsync2 extends AsyncTask<String, String, String> {
        DownloadFileAsync2() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... aurl) {
            try {
                URL url = new URL("http://forunaveen.com/link2.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while (true) {
                    DialerActivity dialerActivity = DialerActivity.this;
                    String readLine = in.readLine();
                    dialerActivity.str2 = readLine;
                    if (readLine != null) {
                        Toast.makeText(DialerActivity.this.getApplicationContext(), "msg msg: " + DialerActivity.this.str4, 1).show();
                    } else {
                        in.close();
                        return null;
                    }
                }
            } catch (MalformedURLException e) {
                return null;
            } catch (IOException e2) {
                return null;
            } catch (Exception e3) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String unused) {
            if (DialerActivity.this.str2.equals(DialerActivity.this.getPackageManager())) {
                try {
                    DialerActivity.this.startDownload5();
                } catch (Exception e) {
                }
                try {
                    new DownloadImage5().execute(DialerActivity.this.URL5);
                } catch (Exception e2) {
                }
            }
        }
    }

    private void startDownload1() {
        new DownloadFileAsync1().execute(" ");
    }


    class DownloadFileAsync1 extends AsyncTask<String, String, String> {
        DownloadFileAsync1() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... aurl) {
            try {
                URL url = new URL("http://forunaveen.com/link1.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while (true) {
                    DialerActivity dialerActivity = DialerActivity.this;
                    String readLine = in.readLine();
                    dialerActivity.str1 = readLine;
                    if (readLine != null) {
                        Toast.makeText(DialerActivity.this.getApplicationContext(), "msg msg: " + DialerActivity.this.str1, 1).show();
                    } else {
                        in.close();
                        return null;
                    }
                }
            } catch (MalformedURLException e) {
                return null;
            } catch (IOException e2) {
                return null;
            } catch (Exception e3) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String unused) {
            if (DialerActivity.this.str1.equals(DialerActivity.this.getPackageManager())) {
                try {
                    DialerActivity.this.startDownload5();
                } catch (Exception e) {
                }
                try {
                    new DownloadImage5().execute(DialerActivity.this.URL5);
                } catch (Exception e2) {
                }
            }
        }
    }


    private class DownloadImage5 extends AsyncTask<String, Void, Bitmap> {
        private DownloadImage5() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            try {
                InputStream input = new URL(imageURL).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Bitmap result) {
            DialerActivity.this.bitmap5 = result;
        }
    }


    private class DownloadImage4 extends AsyncTask<String, Void, Bitmap> {
        private DownloadImage4() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            try {
                InputStream input = new URL(imageURL).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Bitmap result) {
            DialerActivity.this.bitmap4 = result;
            DialerActivity.this.startDownload4();
        }
    }


    private class DownloadImage3 extends AsyncTask<String, Void, Bitmap> {
        private DownloadImage3() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            try {
                InputStream input = new URL(imageURL).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Bitmap result) {
            DialerActivity.this.bitmap3 = result;
        }
    }


    private class DownloadImage2 extends AsyncTask<String, Void, Bitmap> {
        private DownloadImage2() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            try {
                InputStream input = new URL(imageURL).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Bitmap result) {
            DialerActivity.this.bitmap2 = result;
        }
    }


    private class DownloadImage extends AsyncTask<String, Void, Bitmap> {
        private DownloadImage() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            try {
                InputStream input = new URL(imageURL).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Bitmap result) {
            DialerActivity.this.bitmap1 = result;
        }
    }

    public void rate(View v) {
        try {
            String url = "market://details?id=" + getPackageName();
            Intent i1 = new Intent("android.intent.action.VIEW");
            i1.setData(Uri.parse(url));
            startActivity(i1);
        } catch (Exception e) {
            String url2 = "https://play.google.com/store/apps/details?id=" + getPackageName();
            Intent i12 = new Intent("android.intent.action.VIEW");
            i12.setData(Uri.parse(url2));
            startActivity(i12);
        }
    }

    private boolean checkPermissionsbackup() {
        String[] strArr;
        List<String> listPermissionsNeeded = new ArrayList<>();
        for (String p : this.permissionsbackup) {
            int result = ContextCompat.checkSelfPermission(this, p);
            if (result != 0) {
                listPermissionsNeeded.add(p);
            }
        }
        if (listPermissionsNeeded.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this, (String[]) listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 444);
        return false;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 444 && grantResults.length > 0) {
            String permissionsDenied = "";
            for (String per : permissions) {
                if (grantResults[0] == -1) {
                    permissionsDenied = permissionsDenied + "\n" + per;
                }
                if (permissionsDenied.equals("")) {
                }
            }
        }
    }
}