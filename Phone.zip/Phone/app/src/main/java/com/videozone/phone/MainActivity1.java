package com.videozone.phone;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.media.tv.AdRequest;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.view.InputDeviceCompat;
import androidx.core.view.ViewCompat;



public class MainActivity1 extends Activity {
    AnimationDrawable animation;
    Bitmap bitmap1;
    Bitmap bitmap2;
    Bitmap bitmap3;
    Bitmap bitmap4;
    Bitmap bitmap5;

    GridView mGrid1;
    ProgressDialog mProgressDialog1;
    ProgressDialog mProgressDialog2;
    ProgressDialog mProgressDialog3;
    ProgressDialog mProgressDialog4;
    ProgressDialog mProgressDialog5;

    MediaPlayer player;
    String str1 = "h";
    String str2 = "h";
    String str3 = "h";
    String str4 = "h";
    String str5 = "h";
    String URL1 = "http://forunaveen.com/one.jpg";
    String URL2 = "http://forunaveen.com/two.jpg";
    String URL3 = "http://forunaveen.com/three.jpg";
    String URL4 = "http://forunaveen.com/four.jpg";
    String URL5 = "http://forunaveen.com/five.jpg";
    String DeviceID = "";
    String emailId = "";
    String rID = "";
    int abc = 0;

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(R.layout.main2);

        LinearLayout layout = (LinearLayout) findViewById(R.id.rootViewGroup);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(-1, -2);

        SharedPreferences sf = getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0);
        String nameInSD2 = sf.getString("name", "");
        String namenumber = sf.getString("number", "");
        String kiss = sf.getString("cube2_shape", "");
        if (nameInSD2.length() > 1) {
            try {
                TextView txt2 = (TextView) findViewById(R.id.txt1);
                txt2.setText(namenumber + "\n\n" + nameInSD2);
                if (kiss.equals("BLACK")) {
                    txt2.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                }
                if (kiss.equals("BLUE")) {
                    txt2.setTextColor(-16776961);
                }
                if (kiss.equals("CYAN")) {
                    txt2.setTextColor(-16711681);
                }
                if (kiss.equals("DKGRAY")) {
                    txt2.setTextColor(-12303292);
                }
                if (kiss.equals("GREEN")) {
                    txt2.setTextColor(-16711936);
                }
                if (kiss.equals("MAGENTA")) {
                    txt2.setTextColor(-65281);
                }
                if (kiss.equals("YELLOW")) {
                    txt2.setTextColor(InputDeviceCompat.SOURCE_ANY);
                }
            } catch (Exception e) {
            }
        } else {
            try {
                ((TextView) findViewById(R.id.txt1)).setText("SMS");
            } catch (Exception e2) {
            }
        }
        Button playButton = (Button) findViewById(R.id.play_pause);
        playButton.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity1.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent().setClass(MainActivity1.this, DialerActivity.class);
                MainActivity1.this.startActivity(intent);
            }
        });
        final Button status = (Button) findViewById(R.id.play_pause3);
        SharedPreferences sf1 = getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0);
        sf1.edit();
        String bg = sf1.getString("window", "enable");
        if (bg.equals("enable")) {
            status.setBackgroundResource(R.drawable.smsoff);
        } else {
            status.setBackgroundResource(R.drawable.smson);
        }
        status.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity1.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SharedPreferences sf2 = MainActivity1.this.getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0);
                sf2.edit();
                String bg2 = sf2.getString("window", "enable");
                if (bg2.equals("enable")) {
                    status.setBackgroundResource(R.drawable.smson);
                    MainActivity1 mainActivity1 = MainActivity1.this;
                    MainActivity1 mainActivity12 = MainActivity1.this;
                    SharedPreferences.Editor se = mainActivity1.getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0).edit();
                    se.putString("window", "desable");
                    se.commit();
                    try {
                        MainActivity1.this.stopService(new Intent(MainActivity1.this, FServicemovable.class));
                        return;
                    } catch (Exception e3) {
                        return;
                    }
                }
                status.setBackgroundResource(R.drawable.smsoff);
                MainActivity1 mainActivity13 = MainActivity1.this;
                MainActivity1 mainActivity14 = MainActivity1.this;
                SharedPreferences.Editor se2 = mainActivity13.getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0).edit();
                se2.putString("window", "enable");
                se2.commit();
                try {
                    MainActivity1.this.startService(new Intent(MainActivity1.this, FServicemovable.class));
                } catch (Exception e4) {
                }
            }
        });
    }

    @Override // android.app.Activity
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == 0) {
        }
        return true;
    }

    public void bu3(View v) {
        Intent localIntent = new Intent();
        try {
            if (Build.VERSION.SDK_INT >= 16) {
                localIntent.setAction("android.service.wallpaper.CHANGE_LIVE_WALLPAPER");
                localIntent.putExtra("android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT", new ComponentName(MainActivity1.class.getPackage().getName(), OmFallWallpaper.class.getCanonicalName()));
                startActivityForResult(localIntent, 0);
                localIntent.setAction("android.service.wallpaper.LIVE_WALLPAPER_CHOOSER");
            } else {
                try {
                    Intent local = new Intent();
                    local.setAction("android.service.wallpaper.LIVE_WALLPAPER_CHOOSER");
                    startActivity(local);
                    Toast.makeText(getApplicationContext(), "Set Live Wallpaper", 0).show();
                } catch (ActivityNotFoundException e) {
                }
            }
        } catch (Exception e2) {
        }
    }

    protected void startAnimation() {
        SharedPreferences sf = getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0);
        String nameInSD2 = sf.getString("name", "");
        String namenumber = sf.getString("number", "");
        String kiss = sf.getString("cube2_shape", "");
        if (nameInSD2.length() > 1) {
            try {
                TextView txt2 = (TextView) findViewById(R.id.txt1);
                txt2.setText(namenumber + "\n\n" + nameInSD2);
                if (kiss.equals("BLACK")) {
                    txt2.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                }
                if (kiss.equals("BLUE")) {
                    txt2.setTextColor(-16776961);
                }
                if (kiss.equals("CYAN")) {
                    txt2.setTextColor(-16711681);
                }
                if (kiss.equals("DKGRAY")) {
                    txt2.setTextColor(-12303292);
                }
                if (kiss.equals("GREEN")) {
                    txt2.setTextColor(-16711936);
                }
                if (kiss.equals("MAGENTA")) {
                    txt2.setTextColor(-65281);
                }
                if (kiss.equals("YELLOW")) {
                    txt2.setTextColor(InputDeviceCompat.SOURCE_ANY);
                }
            } catch (Exception e) {
            }
        }
    }


    class stater implements Runnable {
        stater() {
        }

        @Override // java.lang.Runnable
        public void run() {
            MainActivity1.this.animation.start();
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            this.abc = 100;
            finish();
            return false;
        }
        return false;
    }
}