package com.videozone.phone;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.widget.RemoteViews;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;


public class HelloWidget extends AppWidgetProvider {
    @Override // android.appwidget.AppWidgetProvider
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new MyTime(context, appWidgetManager), 1L, 1000L);
    }


    private class MyTime extends TimerTask {
        AppWidgetManager appWidgetManager;
        DateFormat format = SimpleDateFormat.getTimeInstance(2, Locale.getDefault());
        RemoteViews remoteViews;
        ComponentName thisWidget;

        public MyTime(Context context, AppWidgetManager appWidgetManager) {
            this.appWidgetManager = appWidgetManager;
            this.remoteViews = new RemoteViews(context.getPackageName(), (int) R.layout.widmain);
            this.thisWidget = new ComponentName(context, HelloWidget.class);
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            this.remoteViews.setTextViewText(R.id.widget_textview, "" + this.format.format(new Date()));
            this.appWidgetManager.updateAppWidget(this.thisWidget, this.remoteViews);
        }
    }
}