package com.videozone.phone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


public class FOpenActivity extends Activity {
    public static Activity btcontext;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fmainlock);
        btcontext = this;
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
        FServicemovable.i++;
        stopService(new Intent(this, FServicemovable.class));
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
    }
}