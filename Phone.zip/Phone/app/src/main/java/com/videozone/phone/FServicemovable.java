package com.videozone.phone;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.util.List;


public class FServicemovable extends Service {
    public static List listCity;
    int NOTIFICATION_ID = 101;
    int REQUEST_CODE = 1;
    Button bt;
    private String contactID;
    GestureDetector gestureDetector;
    private LayoutInflater inflater;
    private long mTouchTriggeredTime;
    private LinearLayout mView;
    private WindowManager mWindowManager;
    FOpenActivity mact;
    ImageView myimaage;
    public static WindowManager.LayoutParams params = null;
    public static int i = 0;

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("WrongConstant")
    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        try {
            this.mact = new FOpenActivity();
        } catch (Exception e) {
        }
        try {
            this.gestureDetector = new GestureDetector(getApplicationContext(), new GestureListener());
        } catch (Exception e2) {
        }
        this.mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        this.inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        SharedPreferences sf = getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0);
        sf.getString("name", "hi");
        sf.getString("number", "hi");
        sf.getString("cube2_shape", "hi");
        sf.getString("duration", "hi");
        sf.getString("myname", "hi");
        String ids = sf.getString("id", "hi");
        this.contactID = ids;
        try {
            try {
                params = new WindowManager.LayoutParams(-2, -2, 2005, 8, -3);
            } catch (Exception e3) {
                params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
            }
            params.gravity = 51;
            params.x = 0;
            params.y = 100;
            this.myimaage = new ImageView(this);
            this.mView = (LinearLayout) LayoutInflater.from(getApplicationContext()).inflate(R.layout.fmainlock, (ViewGroup) null);
            this.myimaage.setImageResource(R.drawable.ic);
            this.mWindowManager.addView(this.mView, params);
            try {
                retrieveContactPhoto();
            } catch (Exception e4) {
            }
            try {
                this.mView.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.FServicemovable.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View v) {
                        if (FServicemovable.i % 2 == 0) {
                            FServicemovable.this.startActivity(new Intent(FServicemovable.this, DialerActivity.class).addFlags(268435456));
                        } else {
                            FServicemovable.this.startActivity(new Intent(FServicemovable.this, DialerActivity.class).addFlags(268435456));
                        }
                        FServicemovable.i++;
                    }
                });
                this.mView.setOnTouchListener(new View.OnTouchListener() { // from class: appwala.my.oldphone.dialer.FServicemovable.2
                    private float initialTouchX;
                    private float initialTouchY;
                    private int initialX;
                    private int initialY;
                    private WindowManager.LayoutParams paramsF = FServicemovable.params;

                    @Override // android.view.View.OnTouchListener
                    public boolean onTouch(View v, MotionEvent event) {
                        switch (event.getAction()) {
                            case 0:
                                this.initialX = this.paramsF.x;
                                this.initialY = this.paramsF.y;
                                this.initialTouchX = event.getRawX();
                                this.initialTouchY = event.getRawY();
                                return false;
                            case 1:
                            default:
                                return false;
                            case 2:
                                this.paramsF.x = this.initialX + ((int) (event.getRawX() - this.initialTouchX));
                                this.paramsF.y = this.initialY + ((int) (event.getRawY() - this.initialTouchY));
                                FServicemovable.i = 3;
                                FServicemovable.this.mWindowManager.updateViewLayout(FServicemovable.this.mView, this.paramsF);
                                return false;
                        }
                    }
                });
            } catch (Exception e5) {
            }
        } catch (Exception e6) {
        }
    }

    @Override // android.app.Service
    @Deprecated
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        this.mWindowManager.removeView(this.mView);
    }


    private class GestureListener extends GestureDetector.SimpleOnGestureListener {
        private GestureListener() {
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent e) {
            return true;
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent e) {
            float x = e.getX();
            float y = e.getY();
            Log.d("Double Tap", "Tapped at: (" + x + "," + y + ")");
            FServicemovable.this.startActivity(new Intent(FServicemovable.this, DialerActivity.class).addFlags(268435456));
            return true;
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent var1, int var2, int var3) {
        startForeground(this.NOTIFICATION_ID, getCompatNotification());
        return Service.START_STICKY;
    }

    private Notification getCompatNotification() {
        NotificationCompat.Builder var1 = new NotificationCompat.Builder(this);
        var1.setSmallIcon(R.drawable.icon).setContentTitle("Old Phone Dialer ").setContentText("Floating Old Phone Dialer enabled.Click to Disable").setTicker(" Floating Old Phone Dialer enabled.Click to Disable").setWhen(System.currentTimeMillis());
        Intent var2 = new Intent(getApplicationContext(), MainActivity1.class);
        var1.setContentIntent(PendingIntent.getActivity(this, this.REQUEST_CODE, var2, 0));
        Toast.makeText(getApplicationContext(), "Old Phone Dialer Live Screen", Toast.LENGTH_SHORT).show();
        return var1.build();
    }


    public class CustomDialogClass extends Dialog implements View.OnClickListener {
        public Dialog d;
        public Button no;
        public Button yes;

        public CustomDialogClass(FServicemovable fServicemovable) {
            super(fServicemovable);
        }

        @Override // android.app.Dialog
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            requestWindowFeature(1);
            setContentView(R.layout.alert_dialog1);
            this.yes = (Button) findViewById(R.id.btn_yes);
            this.no = (Button) findViewById(R.id.btn_no);
            this.yes.setOnClickListener(this);
            this.no.setOnClickListener(this);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btn_no /* 2131165193 */:
                case R.id.btn_yes /* 2131165194 */:
                default:
                    dismiss();
                    return;
            }
        }
    }

    private void retrieveContactPhoto() {
        ImageView imageView = (ImageView) this.mView.findViewById(R.id.myLayout);
        imageView.setBackgroundResource(R.mipmap.ic_launcher);
        ImageView imageView1 = (ImageView) this.mView.findViewById(R.id.myLayout1);
        imageView1.setBackgroundResource(R.drawable.neoncircle_00);
    }

    public Bitmap getRoundedShape(Bitmap scaleBitmapImage) {
        Bitmap targetBitmap = Bitmap.createBitmap(70, 70, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(targetBitmap);
        Path path = new Path();
        path.addCircle((70 - 1.0f) / 2.0f, (70 - 1.0f) / 2.0f, Math.min(70, 70) / 2.0f, Path.Direction.CCW);
        canvas.clipPath(path);
        canvas.drawBitmap(scaleBitmapImage, new Rect(0, 0, scaleBitmapImage.getWidth(), scaleBitmapImage.getHeight()), new Rect(0, 0, 70, 70), (Paint) null);
        return targetBitmap;
    }
}