package com.videozone.phone;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.media.tv.AdRequest;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class MainActivity3D extends Activity {
    public static final int MULTIPLE_PERMISSIONS = 10;
    public static final int MULTIPLE_PERMISSIONS_BACKUP = 444;
    private static final int PERMISSIONS_REQUEST_READ_CONTACTS = 100;
    private static final int PERMISSIONS_REQUEST_READ_PHONE_STATE = 113;
    private static final int PERMISSIONS_REQUEST_READ_SMS = 114;
    private static final int PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 112;
    Bitmap bitmap1;
    Bitmap bitmap2;
    Bitmap bitmap3;
    Bitmap bitmap4;
    Bitmap bitmap5;

    ProgressDialog mProgressDialog1;
    ProgressDialog mProgressDialog2;
    ProgressDialog mProgressDialog3;
    ProgressDialog mProgressDialog4;
    ProgressDialog mProgressDialog5;

    int tru = 0;
    int load = 0;
    int possition = 0;
    int on = 1;
    String str1 = "h";
    String str2 = "h";
    String str3 = "h";
    String str4 = "h";
    String str5 = "h";
    String URL1 = "http://forunaveen.com/one.jpg";
    String URL2 = "http://forunaveen.com/two.jpg";
    String URL3 = "http://forunaveen.com/three.jpg";
    String URL4 = "http://forunaveen.com/four.jpg";
    String URL5 = "http://forunaveen.com/five.jpg";
    private SeekBar volumeControltranspareant = null;
    private TextView scantxt = null;
    int grantapp = 0;
    String[] permissions = {"android.permission.PROCESS_OUTGOING_CALLS", "android.permission.READ_CALL_LOG", "android.permission.READ_CONTACTS"};
    String[] permissionsbackup = {"android.permission.CALL_PHONE", "android.permission.VIBRATE", "android.permission.WRITE_CONTACTS", "android.permission.RECORD_AUDIO", "android.permission.WRITE_EXTERNAL_STORAGE"};

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(R.layout.activity_main3d);

        LinearLayout layout = (LinearLayout) findViewById(R.id.rootViewGroup);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(-1, -2);

        if (Build.VERSION.SDK_INT < 23 || checkPermissionsbackup()) {
        }
        try {
            startDownload4();
        } catch (Exception e) {
        }
        try {
            startDownload3();
        } catch (Exception e2) {
        }
        try {
            startDownload2();
        } catch (Exception e3) {
        }
        try {
            startDownload1();
        } catch (Exception e4) {
        }
        try {
            new DownloadImage().execute(this.URL1);
        } catch (Exception e5) {
        }
        try {
            new DownloadImage2().execute(this.URL2);
        } catch (Exception e6) {
        }
        try {
            new DownloadImage3().execute(this.URL3);
        } catch (Exception e7) {
        }
        try {
            new DownloadImage4().execute(this.URL4);
        } catch (Exception e8) {
        }
        this.volumeControltranspareant = (SeekBar) findViewById(R.id.seek1);
        this.scantxt = (TextView) findViewById(R.id.scans);
        this.volumeControltranspareant.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.2
            int progressChanged = 0;

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                this.progressChanged = progress;
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar seekBar) {
                MainActivity3D.this.scantxt.setText(this.progressChanged + " Times Scans to UnLock Mobile");
                SharedPreferences sfa = MainActivity3D.this.getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0);
                SharedPreferences.Editor se = sfa.edit();
                se.putBoolean("is", false);
                if (this.progressChanged == 0) {
                    this.progressChanged = 1;
                }
                se.putInt("count", this.progressChanged);
                se.commit();
            }
        });
        SharedPreferences sf = getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0);
        sf.edit();
        sf.getString("set_background", "on");
    }

    public void rate(View v) {
        Intent intent = new Intent().setClass(this, MainActivity3D.class);
        startActivity(intent);
        try {
            if (Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners").contains(getApplicationContext().getPackageName())) {
                if (Build.VERSION.SDK_INT < 23 || checkPermissionsbackup()) {
                }
            } else {
                Intent i = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
                i.setFlags(268435456);
                startActivity(i);
            }
        } catch (Exception e) {
        }
    }

    public void setwall(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Do you want set " + getString(R.string.app_name) + " as live wallpaper");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                Intent localIntent = new Intent();
                try {
                    if (Build.VERSION.SDK_INT >= 16) {
                        localIntent.setAction("android.service.wallpaper.CHANGE_LIVE_WALLPAPER");
                        localIntent.putExtra("android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT", new ComponentName(MainActivity3D.class.getPackage().getName(), MainActivity3D.class.getCanonicalName()));
                        MainActivity3D.this.startActivityForResult(localIntent, 0);
                        localIntent.setAction("android.service.wallpaper.LIVE_WALLPAPER_CHOOSER");
                    } else {
                        try {
                            Intent local = new Intent();
                            local.setAction("android.service.wallpaper.LIVE_WALLPAPER_CHOOSER");
                            MainActivity3D.this.startActivity(local);
                            Toast.makeText(MainActivity3D.this.getApplicationContext(), "Set Live Wallpaper", Toast.LENGTH_SHORT).show();
                        } catch (ActivityNotFoundException e) {
                        }
                    }
                } catch (Exception e2) {
                }
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        builder.show();
    }

    public void pin(View v) {
        Intent intent = new Intent().setClass(this, MainActivity3D.class);
        startActivity(intent);
    }

    public void test(View v) {
        startActivity(new Intent(this, MainActivity3D.class));
    }

    public void telugu(View v) {
        openplay(getPackageName().toString());
    }

    public void help(View v) {
        startActivity(new Intent(this, MainActivity3D.class));
    }

    @SuppressLint("WrongConstant")
    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            LayoutInflater li = LayoutInflater.from(this);
            View promptsView = li.inflate(R.layout.exitpage, (ViewGroup) null);
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, R.style.NewDialog);
            alertDialogBuilder.setView(promptsView);
            alertDialogBuilder.setCancelable(true);
            final AlertDialog alertDialog = alertDialogBuilder.create();
            Window window = alertDialog.getWindow();
            WindowManager.LayoutParams wlp = window.getAttributes();
            ImageView first = (ImageView) promptsView.findViewById(R.id.lefle11);
            ImageView second = (ImageView) promptsView.findViewById(R.id.lefle12);
            ImageView third = (ImageView) promptsView.findViewById(R.id.lefle13);
            ImageView fourth = (ImageView) promptsView.findViewById(R.id.lefle14);
            if (this.bitmap4 != null) {
                fourth.setImageBitmap(this.bitmap4);
            }
            if (this.str4.equals(getPackageName()) && this.bitmap5 != null) {
                fourth.setImageBitmap(this.bitmap5);
            }
            if (this.bitmap3 != null) {
                third.setImageBitmap(this.bitmap3);
            }
            if (this.str3.equals(getPackageName()) && this.bitmap5 != null) {
                fourth.setImageBitmap(this.bitmap5);
            }
            if (this.bitmap2 != null) {
                second.setImageBitmap(this.bitmap2);
            }
            if (this.str2.equals(getPackageName()) && this.bitmap5 != null) {
                fourth.setImageBitmap(this.bitmap5);
            }
            if (this.bitmap1 != null) {
                first.setImageBitmap(this.bitmap1);
            }
            if (this.str1.equals(getPackageName()) && this.bitmap5 != null) {
                fourth.setImageBitmap(this.bitmap5);
            }
            Animation zoomin = AnimationUtils.loadAnimation(this, R.anim.somet);
            first.startAnimation(zoomin);
            second.startAnimation(zoomin);
            third.startAnimation(zoomin);
            fourth.startAnimation(zoomin);
            ImageView exit = (ImageView) promptsView.findViewById(R.id.exit);
            ImageView cancel = (ImageView) promptsView.findViewById(R.id.cancel);
            ImageView exit4 = (ImageView) promptsView.findViewById(R.id.exit4);
            ImageView rate = (ImageView) promptsView.findViewById(R.id.rate);
            exit4.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.5
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    MainActivity3D.this.tru = 11;
                    MainActivity3D.this.finish();
                    alertDialog.dismiss();
                }
            });
            rate.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.6
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                }
            });
            exit.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.7
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    MainActivity3D.this.tru = 11;
                    MainActivity3D.this.finish();
                    alertDialog.dismiss();
                }
            });
            cancel.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.8
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    MainActivity3D.this.tru = 0;
                    alertDialog.dismiss();
                }
            });
            first.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.9
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    try {
                        if (MainActivity3D.this.str1.length() > 6) {
                            if (MainActivity3D.this.str1.equals(MainActivity3D.this.getPackageName())) {
                                MainActivity3D.this.openplay(MainActivity3D.this.str5);
                            } else {
                                MainActivity3D.this.openplay(MainActivity3D.this.str1);
                            }
                        } else {
                            MainActivity3D.this.openplay("naveen.Transparent");
                        }
                    } catch (Exception e) {
                    }
                    alertDialog.dismiss();
                }
            });
            second.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.10
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    try {
                        if (MainActivity3D.this.str2.length() > 6) {
                            if (MainActivity3D.this.str2.equals(MainActivity3D.this.getPackageName())) {
                                MainActivity3D.this.openplay(MainActivity3D.this.str5);
                            } else {
                                MainActivity3D.this.openplay(MainActivity3D.this.str2);
                            }
                        } else {
                            MainActivity3D.this.openplay("naveen.mycomputerthemefilemanager");
                        }
                    } catch (Exception e) {
                    }
                    alertDialog.dismiss();
                }
            });
            third.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.11
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    try {
                        if (MainActivity3D.this.str3.length() > 6) {
                            if (MainActivity3D.this.str3.equals(MainActivity3D.this.getPackageName())) {
                                MainActivity3D.this.openplay(MainActivity3D.this.str5);
                            } else {
                                MainActivity3D.this.openplay(MainActivity3D.this.str3);
                            }
                        } else {
                            MainActivity3D.this.openplay("naveen.mypdfscanner");
                        }
                    } catch (Exception e) {
                    }
                    alertDialog.dismiss();
                }
            });
            fourth.setOnClickListener(new View.OnClickListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.12
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    try {
                        if (MainActivity3D.this.str4.length() > 6) {
                            if (MainActivity3D.this.str4.equals(MainActivity3D.this.getPackageName())) {
                                MainActivity3D.this.openplay(MainActivity3D.this.str5);
                            } else {
                                MainActivity3D.this.openplay(MainActivity3D.this.str4);
                            }
                        } else {
                            MainActivity3D.this.openplay("appwala.photoinphoto.camera.photoframes");
                        }
                    } catch (Exception e) {
                    }
                    alertDialog.dismiss();
                }
            });
            wlp.flags &= -3;
            wlp.gravity = 17;
            alertDialog.setOnShowListener(new DialogInterface.OnShowListener() { // from class: appwala.my.oldphone.dialer.MainActivity3D.13
                @Override // android.content.DialogInterface.OnShowListener
                public void onShow(DialogInterface dialog) {
                    int titleDividerId = MainActivity3D.this.getResources().getIdentifier("titleDivider", "id", "android");
                    View titleDivider = alertDialog.findViewById(titleDividerId);
                    if (titleDivider != null) {
                        titleDivider.setBackgroundColor(0);
                    }
                }
            });
            window.setAttributes(wlp);
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            alertDialog.show();
            return false;
        }
        return false;
    }

    void openplay(String name) {
        try {
            String url = "market://details?id=" + name;
            Intent i1 = new Intent("android.intent.action.VIEW");
            i1.setData(Uri.parse(url));
            startActivity(i1);
        } catch (Exception e) {
            String url2 = "https://play.google.com/store/apps/details?id=" + name;
            Intent i12 = new Intent("android.intent.action.VIEW");
            i12.setData(Uri.parse(url2));
            startActivity(i12);
        }
    }

    private void startDownload5() {
        new DownloadFileAsync4().execute(" ");
    }


    class DownloadFileAsync5 extends AsyncTask<String, String, String> {
        DownloadFileAsync5() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... aurl) {
            try {
                URL url = new URL("http://forunaveen.com/link5.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while (true) {
                    MainActivity3D mainActivity3D = MainActivity3D.this;
                    String readLine = in.readLine();
                    mainActivity3D.str5 = readLine;
                    if (readLine != null) {
                        Toast.makeText(MainActivity3D.this.getApplicationContext(), "msg msg: " + MainActivity3D.this.str5, Toast.LENGTH_LONG).show();
                    } else {
                        in.close();
                        return null;
                    }
                }
            } catch (MalformedURLException e) {
                return null;
            } catch (IOException e2) {
                return null;
            } catch (Exception e3) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String unused) {
        }
    }

    private void startDownload4() {
        new DownloadFileAsync4().execute(" ");
    }


    class DownloadFileAsync4 extends AsyncTask<String, String, String> {
        DownloadFileAsync4() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... aurl) {
            try {
                URL url = new URL("http://forunaveen.com/link4.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while (true) {
                    MainActivity3D mainActivity3D = MainActivity3D.this;
                    String readLine = in.readLine();
                    mainActivity3D.str4 = readLine;
                    if (readLine != null) {
                        Toast.makeText(MainActivity3D.this.getApplicationContext(), "msg msg: " + MainActivity3D.this.str4, Toast.LENGTH_LONG).show();
                    } else {
                        in.close();
                        return null;
                    }
                }
            } catch (MalformedURLException e) {
                return null;
            } catch (IOException e2) {
                return null;
            } catch (Exception e3) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String unused) {
        }
    }

    private void startDownload3() {
        new DownloadFileAsync3().execute(" ");
    }


    class DownloadFileAsync3 extends AsyncTask<String, String, String> {
        DownloadFileAsync3() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... aurl) {
            try {
                URL url = new URL("http://forunaveen.com/link3.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while (true) {
                    MainActivity3D mainActivity3D = MainActivity3D.this;
                    String readLine = in.readLine();
                    mainActivity3D.str3 = readLine;
                    if (readLine != null) {
                        Toast.makeText(MainActivity3D.this.getApplicationContext(), "msg msg: " + MainActivity3D.this.str3, Toast.LENGTH_LONG).show();
                    } else {
                        in.close();
                        return null;
                    }
                }
            } catch (MalformedURLException e) {
                return null;
            } catch (IOException e2) {
                return null;
            } catch (Exception e3) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String unused) {
        }
    }

    private void startDownload2() {
        new DownloadFileAsync2().execute(" ");
    }


    class DownloadFileAsync2 extends AsyncTask<String, String, String> {
        DownloadFileAsync2() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... aurl) {
            try {
                URL url = new URL("http://forunaveen.com/link2.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while (true) {
                    MainActivity3D mainActivity3D = MainActivity3D.this;
                    String readLine = in.readLine();
                    mainActivity3D.str2 = readLine;
                    if (readLine != null) {
                        Toast.makeText(MainActivity3D.this.getApplicationContext(), "msg msg: " + MainActivity3D.this.str4, Toast.LENGTH_LONG).show();
                    } else {
                        in.close();
                        return null;
                    }
                }
            } catch (MalformedURLException e) {
                return null;
            } catch (IOException e2) {
                return null;
            } catch (Exception e3) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String unused) {
        }
    }

    private void startDownload1() {
        new DownloadFileAsync1().execute(" ");
    }


    class DownloadFileAsync1 extends AsyncTask<String, String, String> {
        DownloadFileAsync1() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... aurl) {
            try {
                URL url = new URL("http://forunaveen.com/link1.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while (true) {
                    MainActivity3D mainActivity3D = MainActivity3D.this;
                    String readLine = in.readLine();
                    mainActivity3D.str1 = readLine;
                    if (readLine != null) {
                        Toast.makeText(MainActivity3D.this.getApplicationContext(), "msg msg: " + MainActivity3D.this.str1, Toast.LENGTH_LONG).show();
                    } else {
                        in.close();
                        return null;
                    }
                }
            } catch (MalformedURLException e) {
                return null;
            } catch (IOException e2) {
                return null;
            } catch (Exception e3) {
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(String... progress) {
            Log.d("ANDRO_ASYNC", progress[0]);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String unused) {
        }
    }


    private class DownloadImage5 extends AsyncTask<String, Void, Bitmap> {
        private DownloadImage5() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
            MainActivity3D.this.mProgressDialog5 = new ProgressDialog(MainActivity3D.this);
            MainActivity3D.this.mProgressDialog5.setMessage("Loading...");
            MainActivity3D.this.mProgressDialog5.setIndeterminate(false);
            MainActivity3D.this.mProgressDialog5.show();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            try {
                InputStream input = new URL(imageURL).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Bitmap result) {
            MainActivity3D.this.bitmap5 = result;
            MainActivity3D.this.mProgressDialog5.dismiss();
        }
    }


    private class DownloadImage4 extends AsyncTask<String, Void, Bitmap> {
        private DownloadImage4() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
            MainActivity3D.this.mProgressDialog4 = new ProgressDialog(MainActivity3D.this);
            MainActivity3D.this.mProgressDialog4.setMessage("Loading...");
            MainActivity3D.this.mProgressDialog4.setIndeterminate(false);
            MainActivity3D.this.mProgressDialog4.show();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            try {
                InputStream input = new URL(imageURL).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Bitmap result) {
            MainActivity3D.this.bitmap4 = result;
            MainActivity3D.this.mProgressDialog4.dismiss();
        }
    }


    private class DownloadImage3 extends AsyncTask<String, Void, Bitmap> {
        private DownloadImage3() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
            MainActivity3D.this.mProgressDialog3 = new ProgressDialog(MainActivity3D.this);
            MainActivity3D.this.mProgressDialog3.setMessage("Loading...");
            MainActivity3D.this.mProgressDialog3.setIndeterminate(false);
            MainActivity3D.this.mProgressDialog3.show();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            try {
                InputStream input = new URL(imageURL).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Bitmap result) {
            MainActivity3D.this.bitmap3 = result;
            MainActivity3D.this.mProgressDialog3.dismiss();
        }
    }


    private class DownloadImage2 extends AsyncTask<String, Void, Bitmap> {
        private DownloadImage2() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
            MainActivity3D.this.mProgressDialog2 = new ProgressDialog(MainActivity3D.this);
            MainActivity3D.this.mProgressDialog2.setMessage("Loading...");
            MainActivity3D.this.mProgressDialog2.setIndeterminate(false);
            MainActivity3D.this.mProgressDialog2.show();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            try {
                InputStream input = new URL(imageURL).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Bitmap result) {
            MainActivity3D.this.bitmap2 = result;
            MainActivity3D.this.mProgressDialog2.dismiss();
        }
    }


    private class DownloadImage extends AsyncTask<String, Void, Bitmap> {
        private DownloadImage() {
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
            MainActivity3D.this.mProgressDialog1 = new ProgressDialog(MainActivity3D.this);
            MainActivity3D.this.mProgressDialog1.setMessage("Loading...");
            MainActivity3D.this.mProgressDialog1.setIndeterminate(false);
            MainActivity3D.this.mProgressDialog1.show();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            try {
                InputStream input = new URL(imageURL).openStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Bitmap result) {
            MainActivity3D.this.bitmap1 = result;
            MainActivity3D.this.mProgressDialog1.dismiss();
        }
    }




    public boolean checkPermissionsbackup() {
        String[] strArr;
        List<String> listPermissionsNeeded = new ArrayList<>();
        for (String p : this.permissionsbackup) {
            int result = ContextCompat.checkSelfPermission(this, p);
            if (result != 0) {
                listPermissionsNeeded.add(p);
            }
        }
        if (listPermissionsNeeded.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this, (String[]) listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 444);
        return false;
    }


    @Override // android.app.Activity
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 444 && grantResults.length > 0) {
            String permissionsDenied = "";
            for (String per : permissions) {
                if (grantResults[0] == -1) {
                    permissionsDenied = permissionsDenied + "\n" + per;
                }
                if (permissionsDenied.equals("")) {
                    try {
                        if (!Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners").contains(getApplicationContext().getPackageName())) {
                            Intent i = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
                            i.setFlags(268435456);
                            startActivity(i);
                        }
                    } catch (Exception e) {
                    }
                }
            }
        }
    }
}