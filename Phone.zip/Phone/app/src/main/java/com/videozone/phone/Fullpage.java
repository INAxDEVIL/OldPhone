package com.videozone.phone;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.media.tv.AdRequest;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.GridView;
import android.widget.Toast;



public class Fullpage extends Activity {
    private Context context;
    private LayoutInflater layoutInflater;
    GridView mGrid1;
    private SurfaceView preview = null;
    private SurfaceHolder previewHolder = null;
    private Camera camera = null;
    private boolean inPreview = false;
    private boolean cameraConfigured = false;

    int abc = 0;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exitpage);
        try {
            Toast.makeText(this, "Please dial 123", Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "Please dial 7899999", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
        }
        startService(new Intent(this, FServicemovable.class));
}

    public void game14(View v) {
        openlink("calleridlocation");
    }

    public void game13(View v) {
        openlink("Transparent");
    }

    public void game12(View v) {
        openlink("groupslefie");
    }

    public void game11(View v) {
        openlink("autocallanswercallerid");
    }

    public void game15(View v) {
        openlink("speakkeyboardlite");
    }

    public void starts(View v) {
        this.abc = 122;
        finish();
    }

    public void start(View v) {

        Intent intent = new Intent().setClass(this, DialerActivity.class);
        startActivity(intent);
    }

    public void exit(View v) {
        this.abc = 1223;
        finish();
    }

    public void note(View v) {
        Intent intent = new Intent().setClass(this, DialerActivity.class);
        startActivity(intent);
    }

    void openlink(String name) {
        try {
            String url = "market://details?id=naveen." + name;
            Intent i1 = new Intent("android.intent.action.VIEW");
            i1.setData(Uri.parse(url));
            startActivity(i1);
        } catch (Exception e) {
            String url2 = "https://play.google.com/store/apps/details?id=naveen." + name;
            Intent i12 = new Intent("android.intent.action.VIEW");
            i12.setData(Uri.parse(url2));
            startActivity(i12);
        }
    }

    void openlinki(String name) {
        try {
            PackageManager pm = getPackageManager();
            String packageName = "." + name;
            Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
            startActivity(launchIntent);
        } catch (ActivityNotFoundException e) {
            try {
                String url = "market://details?id=." + name;
                Intent i1 = new Intent("android.intent.action.VIEW");
                i1.setData(Uri.parse(url));
                startActivity(i1);
            } catch (Exception e2) {
                String url2 = "https://play.google.com/store/apps/details?id=." + name;
                Intent i12 = new Intent("android.intent.action.VIEW");
                i12.setData(Uri.parse(url2));
                startActivity(i12);
            }
        } catch (Exception e3) {
            try {
                String url3 = "market://details?id=." + name;
                Intent i13 = new Intent("android.intent.action.VIEW");
                i13.setData(Uri.parse(url3));
                startActivity(i13);
            } catch (Exception e4) {
                String url4 = "https://play.google.com/store/apps/details?id=." + name;
                Intent i14 = new Intent("android.intent.action.VIEW");
                i14.setData(Uri.parse(url4));
                startActivity(i14);
            }
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            Intent intent = new Intent().setClass(this, DialerActivity.class);
            startActivity(intent);
            return true;
        }
        return true;
    }
}