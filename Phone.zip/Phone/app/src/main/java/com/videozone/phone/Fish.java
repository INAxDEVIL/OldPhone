package com.videozone.phone;


public class Fish {
    int imgNo;
    int side;
    int vx;
    int x;
    int y;

    void set(int _x, int _y, int _vx, int _imgNo, int _side) {
        this.x = _x;
        this.y = _y;
        this.vx = 200;
        this.imgNo = _imgNo;
        this.side = _side;
    }
}