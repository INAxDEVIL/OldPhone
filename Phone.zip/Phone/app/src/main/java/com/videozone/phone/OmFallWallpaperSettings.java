package com.videozone.phone;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;


public class OmFallWallpaperSettings extends PreferenceActivity implements SharedPreferences.OnSharedPreferenceChangeListener, Preference.OnPreferenceClickListener {
    public static final String BG_IMAGE_KEY1 = "bgImagePref1";
    public static final String BG_IMAGE_KEY10 = "bgImagePref10";
    public static final String BG_IMAGE_KEY2 = "bgImagePref2";
    public static final String BG_IMAGE_KEY3 = "bgImagePref3";
    public static final String BG_IMAGE_KEY5 = "bgImagePref5";
    public static final String BG_IMAGE_KEY7 = "bgImagePref7";
    public static final String BG_IMAGE_KEY8 = "bgImagePref8";
    public static final String BG_IMAGE_KEY9 = "bgImagePref9";
    public static final String BG_IMAGE_KEYCh = "bgImagePrefCh";
    public static final String BG_IMAGE_KEYT = "bgImagePrefT";
    String DeviceID = "";
    String emailId = "";
    String rID = "";

    @Override // android.preference.PreferenceActivity, android.app.Activity
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        getPreferenceManager().setSharedPreferencesName(OmFallWallpaper.SHARED_PREFS_NAME);
        addPreferencesFromResource(R.xml.cube2_settings);
        getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
        findPreference(BG_IMAGE_KEY1).setOnPreferenceClickListener(this);
        findPreference(BG_IMAGE_KEY10).setOnPreferenceClickListener(this);
        findPreference(BG_IMAGE_KEY2).setOnPreferenceClickListener(this);
        findPreference(BG_IMAGE_KEY3).setOnPreferenceClickListener(this);
        findPreference(BG_IMAGE_KEY5).setOnPreferenceClickListener(this);
        findPreference(BG_IMAGE_KEY7).setOnPreferenceClickListener(this);
        findPreference(BG_IMAGE_KEY8).setOnPreferenceClickListener(this);
        findPreference(BG_IMAGE_KEY9).setOnPreferenceClickListener(this);
        findPreference(BG_IMAGE_KEYT).setOnPreferenceClickListener(this);
        findPreference(BG_IMAGE_KEYCh).setOnPreferenceClickListener(this);
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
    }

    @Override // android.preference.PreferenceActivity, android.app.ListActivity, android.app.Activity
    protected void onDestroy() {
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        super.onDestroy();
    }

    @Override // android.content.SharedPreferences.OnSharedPreferenceChangeListener
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
    }

    @Override // android.preference.Preference.OnPreferenceClickListener
    public boolean onPreferenceClick(Preference pref) {
        new Intent("android.intent.action.GET_CONTENT");
        if (pref.getKey().equals(BG_IMAGE_KEYCh)) {
        }
        if (pref.getKey().equals(BG_IMAGE_KEYT)) {
        }
        if (pref.getKey().equals(BG_IMAGE_KEY10)) {
            Intent i1 = new Intent("android.intent.action.VIEW");
            i1.setData(Uri.parse("https://play.google.com/store/apps/details?id=wali"));
            startActivity(i1);
            return true;
        }
        return false;
    }
}