package com.videozone.phone;


public class Ballon {
    public int vy;
    public int x;
    public int y;

    void set(int _x, int _y, int _vy) {
        this.x = _x;
        this.y = _y;
        this.vy = _vy;
    }
}