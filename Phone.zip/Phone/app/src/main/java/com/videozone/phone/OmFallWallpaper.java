package com.videozone.phone;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

import androidx.core.view.ViewCompat;

import java.lang.reflect.Array;
import java.util.Random;


public class OmFallWallpaper extends WallpaperService {
    public static final String SHARED_PREFS_NAME = "cube2settings";


    static class ThreeDPoint {
        float x;
        float y;
        float z;

        ThreeDPoint() {
        }
    }


    static class ThreeDLine {
        int endPoint;
        int startPoint;

        ThreeDLine() {
        }
    }

    @Override // android.service.wallpaper.WallpaperService, android.app.Service
    public void onCreate() {
        super.onCreate();
    }

    @Override // android.service.wallpaper.WallpaperService, android.app.Service
    public void onDestroy() {
        super.onDestroy();
    }

    @Override // android.service.wallpaper.WallpaperService
    public WallpaperService.Engine onCreateEngine() {
        return new CubeEngine();
    }


    class CubeEngine extends WallpaperService.Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
        String Dear;
        int a;
        float acc;
        int adcount;
        int angle;
        int anicounter;
        public int animmation;
        int ap;
        Bitmap ball;
        boolean ballFingerMove;
        int ballH;
        int ballW;
        String bg;
        Bitmap bgr;
        int bgrH;
        Bitmap bgrReverse;
        int bgrScroll;
        int bgrW;
        int bp;
        int count;
        int counter;
        int dBgrY;
        Bitmap[] glitter_mImg_leaf;
        int ic1;
        int ic10;
        int ic11;
        int ic12;
        int ic13;
        int ic14;
        int ic15;
        int ic16;
        int ic17;
        int ic18;
        int ic19;
        int ic2;
        int ic20;
        int ic21;
        int ic22;
        int ic23;
        int ic24;
        int ic25;
        int ic26;
        int ic27;
        int ic28;
        int ic29;
        int ic3;
        int ic30;
        int ic4;
        int ic5;
        int ic6;
        int ic7;
        int ic8;
        int ic9;
        Bitmap icon1;
        Bitmap icon2;
        public boolean isTouch;
        String kiss;
        Ballon[] mBallon;
        Bitmap mBmFingerprint;
        private float mCenterX;
        private float mCenterY;
        private final Runnable mDrawCube;
        Fish[] mFish;
        private final Handler mHandler;
        Bitmap mImg_BG;
        Bitmap[] mImg_Ballon;
        Bitmap[] mImg_Bubble;
        Bitmap[] mImg_Mickey;
        Bitmap[] mImg_Mickey_Click;
        Bitmap[][] mImg_leaf;
        ThreeDLine[] mLines;
        int mMaxX;
        int mMaxY;
        private float mOffset;
        ThreeDPoint[] mOriginalPoints;
        private final Paint mPaint;
        private SharedPreferences mPrefs;
        public Random mRand;
        ThreeDPoint[] mRotatedPoints;
        public Snow[] mSnow;
        final int mSnowNo;
        public GlitterSnow[] mSnowglitter;
        final int mSnowglitterNo;
        private long mStartTime;
        int mTime;
        private float mTouchX;
        private float mTouchY;
        private boolean mVisible;
        Matrix matrix;
        int move;
        int mystart;
        String ownkis;
        String ownkis1;
        String ownkis2;
        String ownkis3;
        public Paint paint;
        MediaPlayer player;
        Random rand;
        int resetCount;
        boolean reverseBackroundFirst;
        public int rotation;
        public int rotation1;
        int sky;
        String sound;
        public Paint[] transparentpainthack;
        int x;
        float x1;
        float x10;
        float x11;
        float x12;
        float x2;
        float x3;
        float x4;
        float x5;
        float x6;
        float x7;
        float x8;
        float x9;
        int y;
        float y1;
        float y10;
        float y11;
        float y12;
        float y2;
        float y3;
        float y4;
        float y5;
        float y6;
        float y7;
        float y8;
        float y9;

        Bitmap ImageLoad(String name) {
            int path = OmFallWallpaper.this.getResources().getIdentifier(name, "drawable", OmFallWallpaper.this.getPackageName());
            Drawable temp = OmFallWallpaper.this.getResources().getDrawable(path);
            return ((BitmapDrawable) temp).getBitmap();
        }

        CubeEngine() {
//            super(OmFallWallpaper.this);
            this.mHandler = new Handler();
            this.mPaint = new Paint();
            this.mTouchX = -1.0f;
            this.mTouchY = -1.0f;
            this.count = 0;
            this.a = 0;
            this.adcount = 0;
            this.mystart = 0;
            this.ap = 0;
            this.bp = 0;
            this.bg = "#FF0000";
            this.kiss = "lips12";
            this.ownkis = "no";
            this.ownkis1 = "no";
            this.ownkis2 = "no";
            this.ownkis3 = "no";
            this.sound = "kiss";
            this.Dear = "Dear";
            this.rand = new Random();
            this.x1 = 150.0f;
            this.x2 = -150.0f;
            this.x3 = -150.0f;
            this.x4 = -150.0f;
            this.x5 = -150.0f;
            this.x6 = -150.0f;
            this.x7 = -150.0f;
            this.x8 = -150.0f;
            this.x9 = -150.0f;
            this.x10 = -150.0f;
            this.x11 = -150.0f;
            this.x12 = -150.0f;
            this.y1 = 150.0f;
            this.y2 = -150.0f;
            this.y3 = -150.0f;
            this.y4 = -150.0f;
            this.y5 = -150.0f;
            this.y6 = -150.0f;
            this.y7 = -150.0f;
            this.y8 = -150.0f;
            this.y9 = -150.0f;
            this.y10 = -150.0f;
            this.y11 = -150.0f;
            this.y12 = -150.0f;
            this.sky = 0;
            this.move = 0;
            this.paint = null;
            this.mSnowNo = 25;
            this.rotation = 0;
            this.rotation1 = 0;
            this.animmation = 0;
            this.isTouch = false;
            this.matrix = new Matrix();
            this.mRand = new Random();
            this.anicounter = 0;
            this.resetCount = 0;
            this.mTime = 10;
            this.counter = 0;
            this.mSnowglitterNo = 50;
            try {
                this.mImg_leaf = (Bitmap[][]) Array.newInstance(Bitmap.class, 4, 8);
                this.mImg_leaf[0][0] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[0][1] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[0][2] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[0][3] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[0][4] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[0][5] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[0][6] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[0][7] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[1][0] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[1][1] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[1][2] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[1][3] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[1][4] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[1][5] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[1][6] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[1][7] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[2][0] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[2][1] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[2][2] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[2][3] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[2][4] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[2][5] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[2][6] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[2][7] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[3][0] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[3][1] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[3][2] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[3][3] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[3][4] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[3][5] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[3][6] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_leaf[3][7] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_Mickey = new Bitmap[4];
                for (int i = 0; i < this.mImg_Mickey.length; i++) {
                    this.mImg_Mickey[i] = ImageLoad("a" + (i + 1));
                }
                this.mImg_Mickey_Click = new Bitmap[4];
                for (int i2 = 0; i2 < this.mImg_Mickey.length; i2++) {
                    this.mImg_Mickey_Click[i2] = ImageLoad("c" + (i2 + 1));
                }
                this.mFish = new Fish[20];
                for (int i3 = 0; i3 < this.mFish.length; i3++) {
                    this.mFish[i3] = new Fish();
                    this.mFish[i3].set(-100, -20, -100, -100, 0);
                }
            } catch (Exception e) {
            }
            this.glitter_mImg_leaf = new Bitmap[10];
            this.glitter_mImg_leaf[0] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.glitter_mImg_leaf[1] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.glitter_mImg_leaf[2] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.glitter_mImg_leaf[3] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.glitter_mImg_leaf[4] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.glitter_mImg_leaf[5] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.glitter_mImg_leaf[6] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.glitter_mImg_leaf[7] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.glitter_mImg_leaf[8] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.glitter_mImg_leaf[9] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.icon1 = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.base);
            this.icon2 = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.base_selector);
            this.ic1 = 20;
            this.ic2 = 20;
            this.ic3 = 20;
            this.ic4 = 20;
            this.ic5 = 20;
            this.ic6 = 20;
            this.ic7 = 20;
            this.ic8 = 20;
            this.ic9 = 20;
            this.ic10 = 20;
            this.ic11 = 20;
            this.ic12 = 20;
            this.ic13 = 0;
            this.ic14 = 0;
            this.ic15 = 0;
            this.ic16 = 0;
            this.ic17 = 0;
            this.ic18 = 0;
            this.ic19 = 0;
            this.ic20 = 0;
            this.ic21 = 0;
            this.ic22 = 0;
            this.ic23 = 0;
            this.ic24 = 0;
            this.ic25 = 0;
            this.ic26 = 0;
            this.ic27 = 0;
            this.ic28 = 0;
            this.ic29 = 0;
            this.ic30 = 0;
            this.mBmFingerprint = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
            this.mDrawCube = new Runnable() { // from class: appwala.my.oldphone.dialer.OmFallWallpaper.CubeEngine.1
                @Override // java.lang.Runnable
                public void run() {
                    CubeEngine.this.drawFrame();
                }
            };
            Paint paint = this.mPaint;
            paint.setColor(-1);
            paint.setAntiAlias(true);
            paint.setStrokeWidth(2.0f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStyle(Paint.Style.STROKE);
            this.mStartTime = SystemClock.elapsedRealtime();
            this.mPrefs = OmFallWallpaper.this.getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0);
            this.mPrefs.registerOnSharedPreferenceChangeListener(this);
            onSharedPreferenceChanged(this.mPrefs, null);
        }

        @Override // android.content.SharedPreferences.OnSharedPreferenceChangeListener
        public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
            String shape = prefs.getString("cube2_shape", "lipsch1");
            String background = prefs.getString("set_background", "back31");
            String soundkiss = prefs.getString("set_sound", "Mute");
            String ownshape = prefs.getString("ownkiss", "cube");
            String name = prefs.getString("name", "Darling");
            if (this.bg.length() > 0) {
                this.bg = background;
            }
            if (this.sound.length() > 0) {
                this.sound = soundkiss;
            }
            if (shape.length() > 0) {
                this.kiss = shape;
            }
            if (ownshape.length() > 0) {
                this.ownkis = ownshape;
            }
            if (name.length() > 0) {
                this.Dear = name;
            }
            this.move = 0;
            startDownload();
            try {
                if (this.bg.length() > 0) {
                    if (this.bg.equals("back31")) {
                        this.icon1 = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.base);
                        this.icon1 = Bitmap.createScaledBitmap(this.icon1, (this.x * 4) / 4, (this.y * 4) / 4, true);
                    }
                    if (this.bg.equals("random")) {
                    }
                }
            } catch (Exception e) {
            }
            readModel("cube");
        }

        void init() {
            try {
                this.mImg_Ballon = new Bitmap[8];
                this.mImg_Ballon[0] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_Ballon[1] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_Ballon[2] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_Ballon[3] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_Ballon[4] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_Ballon[5] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_Ballon[6] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mImg_Ballon[7] = BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.erase);
                this.mBallon = new Ballon[50];
                for (int i = 0; i < this.mBallon.length; i++) {
                    this.mBallon[i] = new Ballon();
                    this.mBallon[i].set(this.mRand.nextInt(((this.mMaxX - this.mImg_Ballon[0].getWidth()) - (this.mImg_Ballon[0].getWidth() / 2)) + 1) + (this.mImg_Ballon[0].getWidth() / 2), -20, this.mRand.nextInt(2) + 1);
                }
                this.transparentpainthack = new Paint[20];
                for (int i2 = 0; i2 < this.transparentpainthack.length; i2++) {
                    this.transparentpainthack[i2] = new Paint();
                }
            } catch (Exception e) {
            }
        }

        void gameLogic3() {
            this.counter++;
            for (int i = 0; i < 20; i++) {
                Fish fish = this.mFish[i];
                fish.y -= 2;
            }
            if (this.counter % 80 == 0) {
                TouchMe();
            }
        }

        int randomBetween(int low, int high) {
            return this.mRand.nextInt(high - low) + low;
        }

        void TouchMe() {
            for (int i = 0; i < 20; i++) {
                if (this.mFish[i].y < -19) {
                    this.mFish[i].set(randomBetween(10, this.mMaxX - 20), this.mMaxY + 40, 0, Math.abs(randomBetween(0, 4)), 0);
                    return;
                }
            }
        }

        void gameLogic2() {
            this.anicounter++;
            int i = 0;
            while (true) {
                if (i >= this.mBallon.length) {
                    break;
                }
                this.mBallon[i].y -= this.mBallon[i].vy;
                if (this.mBallon[i].y >= -10 || this.anicounter % 10 != 0) {
                    i++;
                } else {
                    this.mBallon[i].set(this.mRand.nextInt(((this.mMaxX - this.mImg_Ballon[0].getWidth()) - (this.mImg_Ballon[0].getWidth() / 2)) + 1) + (this.mImg_Ballon[0].getWidth() / 2), this.mMaxY + 20, this.mRand.nextInt(2) + 1);
                    break;
                }
            }
            if (this.isTouch) {
                for (int i2 = 0; i2 < this.mBallon.length; i2++) {
                    if (this.mBallon[i2].x < this.mMaxX / 2) {
                        Ballon ballon = this.mBallon[i2];
                        ballon.x--;
                    } else {
                        this.mBallon[i2].x++;
                    }
                }
            }
        }

        void glitterInit() {
            this.mSnowglitter = new GlitterSnow[50];
            float y = this.mMaxY;
            for (int i = 0; i < 50; i++) {
                this.mSnowglitter[i] = new GlitterSnow();
                int x = randomBetween(40, this.mMaxX - 40);
                y -= this.mMaxY / 50.0f;
                float vy = (-Math.abs(this.mRand.nextFloat())) - 0.5f;
                this.mSnowglitter[i].set(x, y, 0.0f, vy, x % 10);
            }
        }

        void gameInit() {
            this.mSnow = new Snow[25];
            float y = this.mMaxY;
            for (int i = 0; i < 25; i++) {
                this.mSnow[i] = new Snow();
                int x = Math.abs(this.mRand.nextInt()) % (this.mMaxX - 10);
                y -= this.mMaxY / 25.0f;
                float vy = Math.abs(this.mRand.nextFloat()) + 0.5f;
                this.mSnow[i].set(x, y, 0.0f, vy, x % 4);
            }
        }

        void gameLogic() {
            for (int i = 0; i < 25; i++) {
                this.mSnow[i].y += this.mSnow[i].vy;
                if (this.mSnow[i].y > this.mMaxY) {
                    this.mSnow[i].y = -30.0f;
                    this.mSnow[i].x = Math.abs(this.mRand.nextInt()) % (this.mMaxX - 10);
                }
            }
            if (this.isTouch) {
                for (int i2 = 0; i2 < 25; i2++) {
                    if (this.mSnow[i2].x < this.mMaxX / 2) {
                        this.mSnow[i2].x -= 1.0f;
                    } else {
                        this.mSnow[i2].x += 1.0f;
                    }
                }
            }
        }

        void glittergameLogic() {
            for (int i = 0; i < 50; i++) {
                this.mSnowglitter[i].y += this.mSnowglitter[i].vy;
                if (this.counter % 10 == 0) {
                    if (this.mSnowglitter[i].x > this.mMaxX / 2) {
                        this.mSnowglitter[i].x -= 1.0f;
                    } else {
                        this.mSnowglitter[i].x += 1.0f;
                    }
                }
                if (this.mSnowglitter[i].y < 0.0f || this.mSnowglitter[i].trans < 0) {
                    this.mSnowglitter[i].y = this.mMaxY + 20;
                    this.mSnowglitter[i].x = randomBetween(40, this.mMaxX - 40);
                    this.mSnowglitter[i].trans = 200;
                }
            }
            this.counter++;
        }

        private void readModel(String prefix) {
            int pid = OmFallWallpaper.this.getResources().getIdentifier(prefix + "points", "array", OmFallWallpaper.this.getPackageName());
            int lid = OmFallWallpaper.this.getResources().getIdentifier(prefix + "lines", "array", OmFallWallpaper.this.getPackageName());
            String[] p = OmFallWallpaper.this.getResources().getStringArray(pid);
            int numpoints = p.length;
            this.mOriginalPoints = new ThreeDPoint[numpoints];
            this.mRotatedPoints = new ThreeDPoint[numpoints];
            for (int i = 0; i < numpoints; i++) {
                this.mOriginalPoints[i] = new ThreeDPoint();
                this.mRotatedPoints[i] = new ThreeDPoint();
                String[] coord = p[i].split(" ");
                this.mOriginalPoints[i].x = Float.valueOf(coord[0]).floatValue();
                this.mOriginalPoints[i].y = Float.valueOf(coord[1]).floatValue();
                this.mOriginalPoints[i].z = Float.valueOf(coord[2]).floatValue();
            }
            String[] l = OmFallWallpaper.this.getResources().getStringArray(lid);
            int numlines = l.length;
            this.mLines = new ThreeDLine[numlines];
            for (int i2 = 0; i2 < numlines; i2++) {
                this.mLines[i2] = new ThreeDLine();
                String[] idx = l[i2].split(" ");
                this.mLines[i2].startPoint = Integer.valueOf(idx[0]).intValue();
                this.mLines[i2].endPoint = Integer.valueOf(idx[1]).intValue();
            }
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            setTouchEventsEnabled(true);
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onDestroy() {
            super.onDestroy();
            this.mHandler.removeCallbacks(this.mDrawCube);
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onVisibilityChanged(boolean visible) {
            this.mVisible = visible;
            if (visible) {
                drawFrame();
            } else {
                this.mHandler.removeCallbacks(this.mDrawCube);
            }
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            this.mCenterX = width / 2.0f;
            this.mCenterY = height / 2.0f;
            this.x = width;
            this.y = height;
            try {
                this.icon1 = Bitmap.createScaledBitmap(this.icon1, (this.x * 4) / 4, (this.y * 4) / 4, true);
            } catch (Exception e) {
            }
            startDownload();
            drawFrame();
            this.mMaxX = this.x;
            this.mMaxY = this.y;
            try {
                gameInit();
                init();
                glitterInit();
            } catch (Exception e2) {
            }
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            this.mVisible = false;
            this.mHandler.removeCallbacks(this.mDrawCube);
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onOffsetsChanged(float xOffset, float yOffset, float xStep, float yStep, int xPixels, int yPixels) {
            this.mOffset = xOffset;
            drawFrame();
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onTouchEvent(MotionEvent event) {
            if (event.getAction() == 2) {
                this.mTouchX = event.getX();
                this.mTouchY = event.getY();
            } else {
                this.mTouchX = -1.0f;
                this.mTouchY = -1.0f;
            }
            super.onTouchEvent(event);
        }

        boolean RectsIntersect(int AMinX, int AMinY, int AMaxX, int AMaxY, int BMinX, int BMinY, int BMaxX, int BMaxY) {
            return BMinX > AMinX && BMaxX < AMaxX && BMinY > AMinY && BMaxY < AMaxY;
        }

        private void startDownload() {
            this.mystart = 0;
            new DownloadFileAsync().execute(" ");
        }


        class DownloadFileAsync extends AsyncTask<String, String, String> {
            DownloadFileAsync() {
            }

            @Override // android.os.AsyncTask
            protected void onPreExecute() {
                super.onPreExecute();
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // android.os.AsyncTask
            public String doInBackground(String... aurl) {
                try {
                    if (CubeEngine.this.bg.equals("back31")) {
                        CubeEngine.this.icon1 = Bitmap.createScaledBitmap(CubeEngine.this.icon1, CubeEngine.this.x, CubeEngine.this.x, true);
                        CubeEngine.this.icon2 = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.base_selector), CubeEngine.this.x, CubeEngine.this.x, true);
                    } else if (CubeEngine.this.bg.equals("back32")) {
                        CubeEngine.this.icon1 = Bitmap.createScaledBitmap(CubeEngine.this.icon1, CubeEngine.this.x, CubeEngine.this.x, true);
                        CubeEngine.this.icon2 = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.base_selector), CubeEngine.this.x, CubeEngine.this.x, true);
                    } else if (CubeEngine.this.bg.equals("back33")) {
                        CubeEngine.this.icon1 = Bitmap.createScaledBitmap(CubeEngine.this.icon1, CubeEngine.this.x, CubeEngine.this.x, true);
                        CubeEngine.this.icon2 = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.base_selector), CubeEngine.this.x, CubeEngine.this.x, true);
                    } else if (CubeEngine.this.bg.equals("back34")) {
                        CubeEngine.this.icon1 = Bitmap.createScaledBitmap(CubeEngine.this.icon1, CubeEngine.this.x, CubeEngine.this.x, true);
                        CubeEngine.this.icon2 = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.base_selector), CubeEngine.this.x, CubeEngine.this.x, true);
                    } else {
                        CubeEngine.this.icon1 = Bitmap.createScaledBitmap(CubeEngine.this.icon1, CubeEngine.this.x, CubeEngine.this.x, true);
                        CubeEngine.this.icon2 = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(OmFallWallpaper.this.getResources(), R.drawable.base_selector), CubeEngine.this.x, CubeEngine.this.x, true);
                    }
                    return null;
                } catch (Exception e) {
                    return null;
                }
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // android.os.AsyncTask
            public void onProgressUpdate(String... progress) {
                Log.d("ANDRO_ASYNC", progress[0]);
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // android.os.AsyncTask
            public void onPostExecute(String unused) {
            }
        }

        void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder();
            Rect frame = holder.getSurfaceFrame();
            frame.width();
            frame.height();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null) {
                    drawCube(c);
                    drawTouchPoint(c);
                }
                this.mHandler.removeCallbacks(this.mDrawCube);
                if (this.mVisible) {
                    this.mHandler.postDelayed(this.mDrawCube, 52L);
                }
            } finally {
                if (c != null) {
                    holder.unlockCanvasAndPost(c);
                }
            }
        }

        void drawCube(Canvas c) {
            c.save();
            c.translate(this.mCenterX, this.mCenterY);
            c.drawColor(ViewCompat.MEASURED_STATE_MASK);
            long now = SystemClock.elapsedRealtime();
            float xrot = ((float) (now - this.mStartTime)) / 1000.0f;
            float yrot = (0.5f - this.mOffset) * 2.0f;
            float f = ((float) (now - this.mStartTime)) / 2000.0f;
            float f2 = (0.5f - this.mOffset) * 1.0f;
            drawLines(c);
            rotateAndProjectPoints(xrot, yrot);
            this.count++;
            if (this.count == 40) {
                this.count = 1;
            }
            this.a++;
            if (this.a == 3) {
                this.a = 0;
            }
            this.bp++;
            if (this.bp == 3) {
                this.bp = 0;
            }
            this.adcount++;
            if (this.adcount == 17) {
                this.adcount = 1;
            }
            this.mystart++;
            this.ap++;
            if (this.ap == 7) {
                this.ap = 1;
            }
            c.restore();
        }

        void rotateAndProjectPoints(float xrot, float yrot) {
            int n = this.mOriginalPoints.length;
            for (int i = 0; i < n; i++) {
                ThreeDPoint p = this.mOriginalPoints[i];
                float x = p.x;
                float y = p.y;
                float z = p.z;
                float newy = (float) ((Math.sin(xrot) * z) + (Math.cos(xrot) * y));
                float newz = (float) ((Math.cos(xrot) * z) - (Math.sin(xrot) * y));
                float newx = (float) ((Math.sin(yrot) * newz) + (Math.cos(yrot) * x));
                float newz2 = (float) ((Math.cos(yrot) * newz) - (Math.sin(yrot) * x));
                float screenX = newx / (4.0f - (newz2 / 400.0f));
                float screenY = newy / (4.0f - (newz2 / 400.0f));
                this.mRotatedPoints[i].x = screenX;
                this.mRotatedPoints[i].y = screenY;
                this.mRotatedPoints[i].z = 0.0f;
            }
        }

        void drawLines(Canvas c) {
            int n = this.mLines.length;
            for (int i = 0; i < n; i++) {
                try {
                    c.drawColor(Color.parseColor(this.bg));
                } catch (Exception e) {
                }
            }
            drawTouchPoint(c);
        }

        void drawTouchPoint(Canvas c) {
            if (this.mTouchX > 0.0f && this.mTouchY > 0.0f) {
                this.x1 = this.mTouchX;
                this.y1 = this.mTouchY;
            }
            int b = this.icon1.getHeight() / 2;
            int a = this.icon1.getWidth() / 2;
            int d = this.x / 2;
            int e = this.y / 2;
            c.drawColor(Color.parseColor("#41403c"));
            try {
                c.drawBitmap(this.icon1, d - a, e - b, this.mPaint);
                if (this.mTouchX > 0.0f && this.mTouchY > 0.0f) {
                    c.drawBitmap(this.icon2, d - a, e - b, this.mPaint);
                }
                if (this.mystart > 6) {
                    if (this.adcount == 1) {
                    }
                }
            } catch (Exception e2) {
            }
            if (this.mTouchX > 0.0f && this.mTouchY > 0.0f) {
                this.x1 = this.mTouchX;
                this.y1 = this.mTouchY;
            }
            try {
                if (this.mTouchX > 0.0f && this.mTouchY > 0.0f) {
                    this.x1 = this.mTouchX;
                    this.y1 = this.mTouchY;
                    this.isTouch = true;
                    return;
                }
                this.isTouch = false;
            } catch (Exception e3) {
            }
        }
    }
}