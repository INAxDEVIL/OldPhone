package com.videozone.phone;


public class Snow {
    int imgNo;
    float vx;
    float vy;
    float x;
    float y;
    int direction = 0;
    boolean setMe = false;

    public void set(float _x, float _y, float _vx, float _vy, int _imgNo) {
        this.x = _x;
        this.y = _y;
        this.vy = _vy;
        this.vx = _vx;
        this.imgNo = _imgNo;
    }
}