package com.videozone.phone;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;


public class MyScheduleReceiver extends BroadcastReceiver {
    private static final long REPEAT_TIME = 30000;

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        SharedPreferences sf1 = context.getSharedPreferences(OmFallWallpaper.SHARED_PREFS_NAME, 0);
        sf1.edit();
        String bg = sf1.getString("window", "enable");
        if (bg.equals("enable")) {
            context.startService(new Intent(context, FServicemovable.class));
        }
    }
}